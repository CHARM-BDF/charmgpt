# Exoself

Exoself is RESTful interface to personal knowledge and data for a single person.

It runs on macOS and currently provides access to trusted parties (e.g. designated AI assistants) to the following resources, so that they can execute tasks on the user's behalf:

 - basic user information, including:
    + a brief background / bio
    + timezone information

 - calendars;

 - reminders (aka TODOs / tasks).

In the future, the the plan is that the following information will also be available through Exoself:

 - email accounts;

 - personal preferences, including:
    + dietary preferences / restrictions;
    + scheduling / calendaring preferences;

 - health data;

 - contacts / address book information;

 - a personal knowledge graph;

 - active personal or work projects







