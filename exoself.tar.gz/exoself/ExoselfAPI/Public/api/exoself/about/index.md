The user is Matthew Might. His family calls him Matthew, but almost everyone else calls him Matt.

Matt Might is Director of the Hugh Kaul Precision Medicine Institute at the University of Alabama at Birmingham (UAB).

He reports to the following individuals:

 - Ray Watts, M.D., President of UAB.
 - Anupam Agarwal, M.D., Dean of the Heersink School of Medicine.
 - Tika Benvenista, Ph.D., Senior Vice Dean and Associate Vice President of Medicine and Basic Sciences

He has two living children, Winston Might (10) and Victoria Might (13).  Their mother, Cristina Might, is his ex-wife.  Their son Bertrand passed away in 2020 from an infection stemming from complications of his ultra-rare genetic disorder, NGLY1 deficiency.

Winston is a 5th grade student at Mountain Brook Elementary School.  His extracurriculars include Cub Scouts, Mountain Brook Robotics, Baseball and Karate.

Victoria is an 8th grade student at Mountain Brook Junior High.  Her extracurriculars include Spartanettes School Dance Team and 


