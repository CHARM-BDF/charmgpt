# ExoSelf API Documentation

This **ExoSelf API** documentation describes endpoints for:

- **Calendars** (event-type)
- **Events** (plus advanced filtering, including `notes_length` truncation)
- **Reminder Lists** (reminder-type calendars)
- **Reminders** (with advanced filtering)
- **Availability** (returns both a JSON list of free ranges and a Markdown interpretation; optionally excludes weekends/non-working hours and intersects with user-specified time ranges)
- **Agenda** (returns a JSON list of events plus a Markdown summary, with optional `notes_length` truncation)
- **User** (consolidated user information, including about/bio, time zone, and primary calendars)

All endpoints require an **API key** in the `Authorization` header.

---

## Table of Contents

1. [Authentication](#authentication)  
2. [Base URL](#base-url)  
3. [Error Handling](#error-handling)  
4. [Data Models](#data-models)  
   4.1. [APICalendar](#apicalendar)  
   4.2. [APIEvent](#apievent)  
   4.3. [APIReminderList](#apireminderlist)  
   4.4. [APIReminder](#apireminder)  
   4.5. [FreeInterval (Availability)](#freeinterval-availability)  
5. [Calendars](#calendars)  
   5.1. [GET /calendars](#get-calendars)  
   5.2. [POST /calendars](#post-calendars)  
   5.3. [GET /calendars/{id}](#get-calendarsid)  
   5.4. [PUT /calendars/{id}](#put-calendarsid)  
   5.5. [DELETE /calendars/{id}](#delete-calendarsid)  
6. [Events](#events)  
   6.1. [GET /events (Advanced Filtering)](#get-events-advanced-filtering)  
   6.2. [POST /events](#post-events)  
   6.3. [GET /events/{id}](#get-eventsid)  
   6.4. [PUT /events/{id}](#put-eventsid)  
   6.5. [DELETE /events/{id}](#delete-eventsid)  
7. [Reminder Lists](#reminder-lists)  
   7.1. [GET /reminder-lists](#get-reminder-lists)  
   7.2. [POST /reminder-lists](#post-reminder-lists)  
8. [Reminders](#reminders)  
   8.1. [GET /reminders (Advanced Filtering)](#get-reminders-advanced-filtering)  
   8.2. [POST /reminders](#post-reminders)  
   8.3. [GET /reminders/{id}](#get-remindersid)  
   8.4. [PUT /reminders/{id}](#put-remindersid)  
   8.5. [DELETE /reminders/{id}](#delete-remindersid)  
9. [Availability](#availability)  
   9.1. [GET /availability](#get-availability)  
   9.1.1. [How to URL-encode the `intersect` parameter](#how-to-url-encode-the-intersect-parameter)  
   9.1.2. [All-day events and time zones](#all-day-events-and-time-zones)  
10. [Agenda](#agenda)  
   10.1. [GET /agenda](#get-agenda)  
11. [User](#user)  
   11.1. [GET /user](#get-user)  
   11.2. [GET /user/about](#get-userabout)  
   11.3. [GET /user/timezone](#get-usertimezone)  
   11.4. [GET /user/primary-calendars](#get-userprimary-calendars)

---

## 1. Authentication

Every request requires an **API key** in the HTTP `Authorization` header. You can supply it as either:

1. **Bearer token**:
   ```
   Authorization: Bearer YOUR_API_KEY
   ```
2. **Basic token**:
   ```
   Authorization: Basic YOUR_API_KEY
   ```

A missing or invalid key typically returns `401 Unauthorized` or `403 Forbidden`.

---

## 2. Base URL

For the sake of examples, assume:

```
https://westmoreland.might.net/api/exoself/
```

…but you can substitute any hostname/port if your deployment differs, e.g. `http://127.0.0.1:5001/api/exoself/`.

---

## 3. Error Handling

- **401 / 403**: Missing or invalid token.  
- **400**: Bad request (invalid JSON, missing parameters, etc.).  
- **404**: Not found (invalid ID).  
- **500**: Server error (issues writing to underlying services, like EventKit).

Typical error response:

```json
{
  "error": true,
  "reason": "Detailed error message"
}
```

---

## 4. Data Models

### 4.1. APICalendar

```json
{
  "id": "string",
  "name": "string",
  "isDefault": false
}
```

- **id**: Unique ID for the event-type calendar.  
- **name**: Display name.  
- **isDefault**: Not currently used.

### 4.2. APIEvent

```json
{
  "id": "string",
  "calendarID": "string",
  "calendarName": "string",
  "title": "string",
  "startTime": "ISO8601 datetime",
  "endTime": "ISO8601 datetime",
  "allDay": true/false,
  "location": "string or null",
  "notes": "string or null",
  "recurrenceRule": "string or null",
  "availability": "string or null"
}
```

- **id**: Unique ID for the event (may be `null` if not yet created).
- **calendarID**: ID of its event-type calendar.
- **calendarName**: The name of the associated calendar (e.g. `"Work"`).
- **title**: Event title or subject.
- **startTime** / **endTime**: ISO8601 date-times (may include time zone offsets).
- **allDay**: Whether it’s an all-day event.
- **location** / **notes**: Optional.
- **recurrenceRule**: Not fully implemented.
- **availability**: “busy,” “free,” “tentative,” “unavailable,” etc. Used by availability logic.

### 4.3. APIReminderList

```json
{
  "id": "string",
  "name": "string",
  "isDefault": false
}
```

- **id**: Unique ID for a reminder-type calendar (a to-do list).  
- **name**: Display name.  
- **isDefault**: Not currently used.

### 4.4. APIReminder

```json
{
  "id": "string",
  "title": "string",
  "dueDate": "ISO8601 datetime or null",
  "completed": true/false,
  "notes": "string or null",
  "linkedEventID": "string or null",
  "listID": "string",
  "listName": "string"
}
```

- **id**: Unique ID for the reminder.
- **title**: The “to-do” text.
- **dueDate**: Optional date/time.
- **completed**: Whether it’s marked complete.
- **notes**: Optional.
- **linkedEventID**: Potentially link the reminder to an event.
- **listID**: The ID of the reminder-list calendar.
- **listName**: The name of the reminder list (e.g. `"Errands"`).

### 4.5. FreeInterval (Availability)

When querying the **Availability** endpoint, the response includes an array of `ranges` objects, each with:

```json
{
  "start": "ISO8601 datetime",
  "end": "ISO8601 datetime"
}
```

These represent half-open intervals `[start, end)`. The top-level availability object also includes an `interpretation` field (Markdown).

---

## 5. Calendars

### 5.1. GET /calendars

Fetch all event-type calendars.

**Example**:
```bash
curl -H "Authorization: Bearer supersecret" \
     https://westmoreland.might.net/api/exoself/calendars
```

**Response**:
```json
[
  {
    "id": "CAL_001",
    "name": "Work",
    "isDefault": false
  },
  {
    "id": "CAL_002",
    "name": "Personal",
    "isDefault": false
  }
]
```

---

### 5.2. POST /calendars

Create a new event-type calendar.

**Request Body**:
```json
{
  "name": "New Calendar"
}
```

**Example**:
```bash
curl -X POST \
     -H "Authorization: Bearer supersecret" \
     -H "Content-Type: application/json" \
     -d '{"name": "New Calendar"}' \
     https://westmoreland.might.net/api/exoself/calendars
```

**Response**:
```json
{
  "id": "CAL_003",
  "name": "New Calendar",
  "isDefault": false
}
```

---

### 5.3. GET /calendars/{id}

Retrieve a single event-type calendar by ID.

**Example**:
```bash
curl -H "Authorization: Bearer supersecret" \
     https://westmoreland.might.net/api/exoself/calendars/CAL_003
```

**Response**:
```json
{
  "id": "CAL_003",
  "name": "New Calendar",
  "isDefault": false
}
```

---

### 5.4. PUT /calendars/{id}

Not implemented (returns `501 Not Implemented` or similar).

---

### 5.5. DELETE /calendars/{id}

Delete a calendar by ID.

**Example**:
```bash
curl -X DELETE \
     -H "Authorization: Bearer supersecret" \
     https://westmoreland.might.net/api/exoself/calendars/CAL_003
```

**Response**: `204 No Content` on success, `404` if not found.

---

## 6. Events

### 6.1. GET /events (Advanced Filtering)

Retrieve events across one or all calendars, with optional substring/time-based filters **and** optional `notes_length` truncation.

**Query Parameters**:
- **`calendar_id`**: Filter by a single calendar ID.
- **`title_contains`**: Case-insensitive substring for event titles.
- **`notes_contains`**: Case-insensitive substring in notes.
- **`start_after`**: Minimal start date-time (ISO8601).
- **`end_before`**: Maximal end date-time (ISO8601).
- **`within_seconds`**: e.g. `3600` => events overlapping `[now, now+3600]`.
- **`before_time`**: Overlap only with times before this ISO8601 date-time.
- **`after_time`**: Overlap only with times after this ISO8601 date-time.
- **`notes_length`** (optional):  
  - If omitted or invalid, defaults to **100** (characters).  
  - If `"all"`, returns full `notes` with no truncation.  
  - If a positive integer, truncates `notes` to that many characters.

**Example**:
```bash
curl "https://westmoreland.might.net/api/exoself/events?calendar_id=CAL_001\
      &title_contains=meeting\
      &notes_contains=urgent\
      &within_seconds=3600\
      &notes_length=200" \
     -H "Authorization: Bearer supersecret"
```

**Response**:
```json
[
  {
    "id": "EVENT_ABC",
    "calendarID": "CAL_001",
    "calendarName": "Work",
    "title": "Meeting with urgent client",
    "startTime": "2025-01-10T10:00:00Z",
    "endTime": "2025-01-10T11:00:00Z",
    "allDay": false,
    "location": "Conference Room A",
    "notes": "...(up to 200 characters of notes)...",
    "recurrenceRule": null,
    "availability": "busy"
  },
  ...
]
```

---

### 6.2. POST /events

Create a new event.

**Request Body** (example):
```json
{
  "calendarID": "CAL_001",
  "calendarName": "Work",
  "title": "Project Kickoff",
  "startTime": "2025-01-10T10:00:00Z",
  "endTime": "2025-01-10T11:00:00Z",
  "allDay": false,
  "availability": "busy"
}
```

**Example**:
```bash
curl -X POST \
     -H "Authorization: Bearer supersecret" \
     -H "Content-Type: application/json" \
     -d '{
       "calendarID": "CAL_001",
       "calendarName": "Work",
       "title": "Project Kickoff",
       "startTime": "2025-01-10T10:00:00Z",
       "endTime": "2025-01-10T11:00:00Z",
       "allDay": false,
       "availability": "busy"
     }' \
     https://westmoreland.might.net/api/exoself/events
```

**Response**:
```json
{
  "id": "EVENT_ABC",
  "calendarID": "CAL_001",
  "calendarName": "Work",
  "title": "Project Kickoff",
  "startTime": "2025-01-10T10:00:00Z",
  "endTime": "2025-01-10T11:00:00Z",
  "allDay": false,
  "location": null,
  "notes": null,
  "recurrenceRule": null,
  "availability": "busy"
}
```

---

### 6.3. GET /events/{id}

Retrieve a single event by ID, optionally truncating `notes` via `notes_length`.

**Query Parameters**:
- **`notes_length`** (optional): same behavior as in [GET /events](#get-events-advanced-filtering).

**Example**:
```bash
curl -H "Authorization: Bearer supersecret" \
     "https://westmoreland.might.net/api/exoself/events/EVENT_ABC?notes_length=all"
```

**Response**:
```json
{
  "id": "EVENT_ABC",
  "calendarID": "CAL_001",
  "calendarName": "Work",
  "title": "Project Kickoff",
  "startTime": "2025-01-10T10:00:00Z",
  "endTime": "2025-01-10T11:00:00Z",
  "allDay": false,
  "location": null,
  "notes": "Full notes text here...",
  "recurrenceRule": null,
  "availability": "busy"
}
```

---

### 6.4. PUT /events/{id}

Update an existing event.

**Request Body** (example):
```json
{
  "id": "EVENT_ABC",
  "calendarID": "CAL_001",
  "calendarName": "Work",
  "title": "Kickoff Meeting (Updated)",
  "startTime": "2025-01-10T09:30:00Z",
  "endTime": "2025-01-10T10:30:00Z",
  "allDay": false,
  "availability": "tentative"
}
```

**Example**:
```bash
curl -X PUT \
     -H "Authorization: Bearer supersecret" \
     -H "Content-Type: application/json" \
     -d '{
       "calendarID": "CAL_001",
       "calendarName": "Work",
       "title": "Kickoff Meeting (Updated)",
       "startTime": "2025-01-10T09:30:00Z",
       "endTime": "2025-01-10T10:30:00Z",
       "allDay": false,
       "availability": "tentative"
     }' \
     https://westmoreland.might.net/api/exoself/events/EVENT_ABC
```

**Response**:
```json
{
  "id": "EVENT_ABC",
  "calendarID": "CAL_001",
  "calendarName": "Work",
  "title": "Kickoff Meeting (Updated)",
  "startTime": "2025-01-10T09:30:00Z",
  "endTime": "2025-01-10T10:30:00Z",
  "allDay": false,
  "location": null,
  "notes": null,
  "recurrenceRule": null,
  "availability": "tentative"
}
```

---

### 6.5. DELETE /events/{id}

Delete an event by ID.

**Example**:
```bash
curl -X DELETE \
     -H "Authorization: Bearer supersecret" \
     https://westmoreland.might.net/api/exoself/events/EVENT_ABC
```

**Response**: `204 No Content` if successful.

---

## 7. Reminder Lists

### 7.1. GET /reminder-lists

Retrieve all reminder-type calendars (lists).

**Example**:
```bash
curl -H "Authorization: Bearer supersecret" \
     https://westmoreland.might.net/api/exoself/reminder-lists
```

**Response**:
```json
[
  {
    "id": "LIST_001",
    "name": "Personal Todos",
    "isDefault": false
  },
  ...
]
```

---

### 7.2. POST /reminder-lists

Create a new reminder list.

**Request Body**:
```json
{
  "name": "Errands"
}
```

**Example**:
```bash
curl -X POST \
     -H "Authorization: Bearer supersecret" \
     -H "Content-Type: application/json" \
     -d '{"name":"Errands"}' \
     https://westmoreland.might.net/api/exoself/reminder-lists
```

**Response**:
```json
{
  "id": "LIST_002",
  "name": "Errands",
  "isDefault": false
}
```

---

## 8. Reminders

### 8.1. GET /reminders (Advanced Filtering)

Retrieve reminders with optional advanced filters:

- `list_id`: Filter by a specific list.
- `completed=true/false`: Filter by completion status.
- `title_contains`, `notes_contains`: Case-insensitive substring match.
- `due_before_time`, `due_after_time`: ISO8601 date-time filters.
- `due_within_seconds`: e.g. `3600` => within next hour, negative => past hour, etc.

**Example**:
```bash
curl "https://westmoreland.might.net/api/exoself/reminders?list_id=LIST_002\
      &completed=false\
      &title_contains=buy\
      &due_within_seconds=86400" \
     -H "Authorization: Bearer supersecret"
```

**Response**:
```json
[
  {
    "id": "REM_001",
    "title": "Buy groceries",
    "dueDate": "2025-02-01T17:00:00Z",
    "completed": false,
    "notes": "Remember milk",
    "linkedEventID": null,
    "listID": "LIST_002",
    "listName": "Errands"
  }
]
```

---

### 8.2. POST /reminders

Create a new reminder in the specified list.

**Request Body**:
```json
{
  "title": "Buy groceries",
  "dueDate": "2025-02-01T17:00:00Z",
  "completed": false,
  "notes": "Remember milk",
  "linkedEventID": null,
  "listID": "LIST_002",
  "listName": "Errands"
}
```

**Example**:
```bash
curl -X POST \
     -H "Authorization: Bearer supersecret" \
     -H "Content-Type: application/json" \
     -d '{
       "title": "Buy groceries",
       "dueDate": "2025-02-01T17:00:00Z",
       "completed": false,
       "notes": "Remember milk",
       "listID": "LIST_002",
       "listName": "Errands"
     }' \
     https://westmoreland.might.net/api/exoself/reminders
```

**Response**:
```json
{
  "id": "REM_001",
  "title": "Buy groceries",
  "dueDate": "2025-02-01T17:00:00Z",
  "completed": false,
  "notes": "Remember milk",
  "linkedEventID": null,
  "listID": "LIST_002",
  "listName": "Errands"
}
```

---

### 8.3. GET /reminders/{id}

Retrieve a single reminder by ID.

**Example**:
```bash
curl -H "Authorization: Bearer supersecret" \
     https://westmoreland.might.net/api/exoself/reminders/REM_001
```

**Response**:
```json
{
  "id": "REM_001",
  "title": "Buy groceries",
  "dueDate": "2025-02-01T17:00:00Z",
  "completed": false,
  "notes": "Remember milk",
  "linkedEventID": null,
  "listID": "LIST_002",
  "listName": "Errands"
}
```

---

### 8.4. PUT /reminders/{id}

Update an existing reminder.

**Example**:
```bash
curl -X PUT \
     -H "Authorization: Bearer supersecret" \
     -H "Content-Type: application/json" \
     -d '{
       "id": "REM_001",
       "title": "Pick up groceries",
       "dueDate": "2025-02-01T18:00:00Z",
       "completed": false,
       "notes": "Milk & eggs",
       "listID": "LIST_002",
       "listName": "Errands"
     }' \
     https://westmoreland.might.net/api/exoself/reminders/REM_001
```

**Response**:
```json
{
  "id": "REM_001",
  "title": "Pick up groceries",
  "dueDate": "2025-02-01T18:00:00Z",
  "completed": false,
  "notes": "Milk & eggs",
  "linkedEventID": null,
  "listID": "LIST_002",
  "listName": "Errands"
}
```

---

### 8.5. DELETE /reminders/{id}

Delete a reminder by ID.

**Example**:
```bash
curl -X DELETE \
     -H "Authorization: Bearer supersecret" \
     https://westmoreland.might.net/api/exoself/reminders/REM_001
```

**Response**: `204 No Content` if successful.

---

## 9. Availability

### 9.1. GET /availability

Finds free time blocks across specified calendars in **15-minute increments**. Returns a JSON object with two fields:

- **`ranges`**: an array of `[start, end)` intervals in ISO8601 form (UTC).  
- **`interpretation`**: a Markdown string describing day-by-day availability in the user’s local time zone.

**Query Parameters**:

| Parameter              | Required? | Description                                                                                                                                                                                                                                                                                                                                                   |
|------------------------|----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `calendar_ids`         | No       | Comma-separated list of calendar IDs. If omitted, uses user’s primary calendars.                                                                                                                                                                                                                                                                             |
| `start`                | Yes (if no other constraints) | ISO8601 start datetime (can include offset, e.g. `2025-02-01T00:00:00-06:00`).                                                                                                                                                                                                                                                                                |
| `end`                  | Yes (if no other constraints) | ISO8601 end datetime (must be after `start`).                                                                                                                                                                                                                                                                                                               |
| `working_hours_only`   | No       | If `true` (default), removes weekends and restricts results to 7 AM–6 PM local time. If `false`, returns 24-hour availability.                                                                                                                                                                                                                                |
| `intersect`            | No       | **Must be valid JSON**, URL-encoded, representing an array of `{ "start": ..., "end": ... }` objects. Each object is an ISO8601 datetime (with or without offsets). The system intersects your free time with these intervals. Any block outside these intervals becomes unavailable. See below for how to pass this param. |
| `min_duration`         | No       | Minimum number of **minutes** for a free block to qualify. If set, the response `ranges` array omits any free interval shorter than this length. If omitted or invalid, all free blocks are returned regardless of length.                                                                                               |

#### Basic Example

```bash
curl -H "Authorization: Bearer supersecret" \
     "https://westmoreland.might.net/api/exoself/availability\
       ?calendar_ids=CAL_001,CAL_002\
       &start=2025-01-05T07:00:00Z\
       &end=2025-01-05T17:00:00Z\
       &working_hours_only=true\
       &min_duration=30"
```

---

#### 9.1.1. How to URL-encode the `intersect` parameter

If you want to provide `intersect` as a JSON array of objects, you **must** URL-encode the entire array so the API can parse it. For instance, if your desired JSON is:

```json
[  
  {
    "start": "2025-01-21T10:00:00-05:00",
    "end":   "2025-01-21T11:00:00-05:00"
  },
  {
    "start": "2025-01-21T15:30:00-05:00",
    "end":   "2025-01-21T17:00:00-05:00"
  }
]
```

Then you must **URL-escape** it. For example (percent-encoding brackets, quotes, colons, etc.):

```
%5B%7B%22start%22%3A%222025-01-21T10%3A00%3A00-05%3A00%22%2C%22end%22%3A%222025-01-21T11%3A00%3A00-05%3A00%22%7D%2C%7B%22start%22%3A%222025-01-21T15%3A30%3A00-05%3A00%22%2C%22end%22%3A%222025-01-21T17%3A00%3A00-05%3A00%22%7D%5D
```

Hence, your request might look like:

```bash
curl -H "Authorization: Bearer supersecret" \
     "https://westmoreland.might.net/api/exoself/availability\
?start=2025-01-21T00:00:00-05:00\
&end=2025-01-21T23:59:59-05:00\
&intersect=%5B%7B%22start%22%3A%222025-01-21T10%3A00%3A00-05%3A00%22%2C%22end%22%3A%222025-01-21T11%3A00%3A00-05%3A00%22%7D%2C%7B%22start%22%3A%222025-01-21T15%3A30%3A00-05%3A00%22%2C%22end%22%3A%222025-01-21T17%3A00%3A00-05%3A00%22%7D%5D"
```

This will ensure that the server decodes `intersect` properly as an array of two objects, each with “start” and “end.” If the string is passed without URL-encoding, the query parser may discard it, resulting in `userIntersectRanges=[]`.

---

#### 9.1.2. All-day events and time zones

- If an event is `allDay == true`, the system interprets it in the user’s **primary time zone** from midnight to the next midnight. Then it converts that range back to UTC for marking blocks as busy.  
- The “interpretation” field in the response is day-by-day in the user’s local time. The `ranges` array is always in UTC.  
- Make sure your `start`/`end` query parameters and intersection ranges are valid ISO8601 strings. Offsets like `-05:00` or `+02:00` are properly parsed into absolute UTC times.

---

## 10. Agenda

### 10.1. GET /agenda

Returns **all events** in a given date range (or on a set of specified days), along with a day-by-day Markdown summary.  
Optionally truncates `notes` with a `notes_length` parameter (same rules as in [GET /events](#get-events-advanced-filtering)).

**Query Parameters**:
- **`days`** (optional):  
  - Either a **range** of days, e.g. `2025-05-01..2025-05-05`,  
  - Or a **comma-separated** list of days, e.g. `2025-05-01,2025-05-03,2025-05-10`.  
  - If provided, this overrides the `start`/`end` query parameters.  
  - Each day must be in the format `yyyy-MM-dd`.
- `start` (optional): a date (yyyy-MM-dd) in user’s local time. Defaults to “today” if `days` is not used.  
- `end` (optional): a date (yyyy-MM-dd) in user’s local time. Defaults to the same day if `days` is not used.  
- `calendar_ids` (optional): If omitted, uses primary calendars.
- **`notes_length`** (optional):  
  - If omitted or invalid, defaults to **100** (characters).  
  - If `"all"`, returns full `notes` with no truncation.  
  - If a positive integer, truncates `notes` to that many characters.

#### Behavior notes for `days`:

- If `days` is provided as a range (`YYYY-MM-DD..YYYY-MM-DD`), the endpoint includes every day in that inclusive range.
- If `days` is provided as a comma-separated list of discrete days, only those specific days are included.
- If no `days` parameter is provided, the endpoint falls back to `start`/`end` (defaulting to today..today if neither is given).
- The endpoint interprets each day in the user’s local time zone. Under the hood, it fetches events from the earliest day’s midnight up to (and not including) the day after the latest day’s midnight.

**Response**: A JSON object with two fields:

- **`events`**: an array of `APIEvent` (with `notes` truncated according to `notes_length` if provided).  
- **`interpretation`**: a Markdown string listing events day by day, e.g.:

  ```
  Tuesday, January 7 2025:
   - 9:00 AM CT  Project Kickoff (CAL_001)
   - 2:00 PM CT  Team Meeting (CAL_002)
  ```

**Example #1**: Range of days  
```bash
curl -H "Authorization: Bearer supersecret" \
     "https://westmoreland.might.net/api/exoself/agenda?days=2025-05-01..2025-05-05&notes_length=all"
```

**Example #2**: Discrete list of days  
```bash
curl -H "Authorization: Bearer supersecret" \
     "https://westmoreland.might.net/api/exoself/agenda?days=2025-05-01,2025-05-03,2025-05-10&notes_length=50"
```

**Example #3**: Fallback to start/end  
```bash
curl -H "Authorization: Bearer supersecret" \
     "https://westmoreland.might.net/api/exoself/agenda?start=2025-01-07&end=2025-01-08"
```

**Response (example)**:
```json
{
  "events": [
    {
      "id": "EVENT_ABC",
      "calendarID": "CAL_001",
      "calendarName": "Work",
      "title": "Project Kickoff",
      "startTime": "2025-01-07T10:00:00Z",
      "endTime": "2025-01-07T11:00:00Z",
      "allDay": false,
      "availability": "busy",
      "notes": "...(potentially truncated)..."
    },
    {
      "id": "EVENT_XYZ",
      "calendarID": "CAL_002",
      "calendarName": "Personal",
      "title": "All-Day Meeting",
      "startTime": "2025-01-08T00:00:00Z",
      "endTime": "2025-01-09T00:00:00Z",
      "allDay": true,
      "availability": "busy",
      "notes": null
    }
  ],
  "interpretation": "Tuesday, January 7 2025:\n - 9:00 AM CT  Project Kickoff (CAL_001)\n\nWednesday, January 8 2025:\n - 12:00 AM CT  All-Day Meeting (CAL_002)\n"
}
```

---

## 11. User

### 11.1. GET /user

Returns all user info in a single JSON object: about/bio (Markdown), timezone, and primary calendars.

**Response**:
```json
{
  "aboutMarkdown": "# About the User\n\nBio content here...",
  "timezone": "America/Chicago",
  "primaryCalendars": [
    "CAL_001",
    "CAL_002"
  ]
}
```

**Example**:
```bash
curl -H "Authorization: Bearer supersecret" \
     https://westmoreland.might.net/api/exoself/user
```

---

### 11.2. GET /user/about

Returns only the user’s “about” text in `text/markdown`.

**Example**:
```bash
curl -H "Authorization: Bearer supersecret" \
     https://westmoreland.might.net/api/exoself/user/about
```

**Response** (`text/markdown`):
```
# About the User

Matthew Might is ...
```

---

### 11.3. GET /user/timezone

Returns only the user’s primary time zone in JSON.

**Example**:
```bash
curl -H "Authorization: Bearer supersecret" \
     https://westmoreland.might.net/api/exoself/user/timezone
```

**Response**:
```json
{
  "timezone": "America/Chicago"
}
```

---

### 11.4. GET /user/primary-calendars

Returns only the user’s primary calendar IDs as a JSON array.

**Example**:
```bash
curl -H "Authorization: Bearer supersecret" \
     https://westmoreland.might.net/api/exoself/user/primary-calendars
```

**Response**:
```json
[
  "CAL_001",
  "CAL_002"
]
```
