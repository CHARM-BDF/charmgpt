import Vapor

struct UserInfoController: RouteCollection {
    let userInfoService: UserInfoService

    func boot(routes: RoutesBuilder) throws {
        // e.g. GET /about
        routes.get("about", use: getAbout)
        // e.g. GET /primary-calendars
        routes.get("primary-calendars", use: getPrimaryCalendars)
    }

    /// GET /about
    /// Returns the user’s bio in markdown form.
    func getAbout(_ req: Request) async throws -> Response {
        // If you want to return as text/markdown:
        let bioText = userInfoService.aboutMarkdown()
        let headers: HTTPHeaders = ["Content-Type": "text/markdown; charset=utf-8"]
        return Response(status: .ok, headers: headers, body: .init(string: bioText))
    }

    /// GET /primary-calendars
    /// Returns user’s list of primary calendars.
    func getPrimaryCalendars(_ req: Request) async throws -> [String] {
        userInfoService.primaryCalendars()
    }
}
