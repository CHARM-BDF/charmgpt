import Vapor
@preconcurrency import EventKit  // if needed

struct ReminderController: RouteCollection {
    let eventKitActor: EventKitActor
    
    func boot(routes: RoutesBuilder) throws {
        let reminders = routes.grouped("reminders")
        reminders.get(use: getAllReminders)
        reminders.post(use: createReminder)
        
        reminders.group(":id") { rem in
            rem.get(use: getReminder)
            rem.put(use: updateReminder)
            rem.delete(use: deleteReminder)
        }
    }

    // GET /reminders with advanced query parameters
    // e.g. /reminders?list_id=XYZ&completed=false&title_contains=buy&due_within_seconds=86400
    func getAllReminders(_ req: Request) async throws -> [APIReminder] {
        // -- Existing param for the list --
        let listID: String? = req.query["list_id"]
        
        // -- New filters --
        let completedParam: Bool? = req.query["completed"]
        
        let titleRaw: String? = req.query["title_contains"]
        let notesRaw: String? = req.query["notes_contains"]
        let titleSub = titleRaw?.lowercased()
        let notesSub = notesRaw?.lowercased()
        
        // -- Time-based filters for dueDate --
        let dueBeforeStr:  String? = req.query["due_before_time"]
        let dueAfterStr:   String? = req.query["due_after_time"]
        let dueWithinSecs: Int?    = req.query["due_within_seconds"]
        
        let iso = ISO8601DateFormatter()
        let dueBefore = dueBeforeStr.flatMap { iso.date(from: $0) }
        let dueAfter  = dueAfterStr.flatMap  { iso.date(from: $0) }
        
        // If within_seconds is set, interpret that as a range from now
        let now = Date()
        var dueRange: (Date, Date)? = nil
        if let secs = dueWithinSecs {
            if secs >= 0 {
                // from now to now+secs
                dueRange = (now, now.addingTimeInterval(TimeInterval(secs)))
            } else {
                // negative => range is (now+secs, now)
                dueRange = (now.addingTimeInterval(TimeInterval(secs)), now)
            }
        }
        
        // 1) Fetch from the actor
        var allRems = try await eventKitActor.fetchReminders(listID: listID)
        
        // 2) Filter in memory
        allRems = allRems.filter { reminder in
            
            // a) completed?
            if let cParam = completedParam, reminder.completed != cParam {
                return false
            }
            
            // b) title/notes substring
            if let tSub = titleSub,
               !reminder.title.lowercased().contains(tSub)
            {
                return false
            }
            if let nSub = notesSub {
                let rNotes = (reminder.notes ?? "").lowercased()
                if !rNotes.contains(nSub) {
                    return false
                }
            }
            
            // c) Due date constraints
            guard let due = reminder.dueDate else {
                // If user is filtering by times, skip items w/o a dueDate
                if dueBefore != nil || dueAfter != nil || dueRange != nil {
                    return false
                }
                return true
            }
            
            // If within range:
            if let (rStart, rEnd) = dueRange {
                if !(due >= rStart && due <= rEnd) {
                    return false
                }
            }
            
            // If we have dueAfter, must be due > dueAfter
            if let dA = dueAfter, due <= dA {
                return false
            }
            
            // If we have dueBefore, must be due < dueBefore
            if let dB = dueBefore, due >= dB {
                return false
            }
            
            return true
        }
        
        return allRems
    }

    // POST /reminders
    func createReminder(_ req: Request) async throws -> APIReminder {
        let data = try req.content.decode(APIReminder.self)
        return try await eventKitActor.createReminder(data)
    }
    
    // GET /reminders/:id
    func getReminder(_ req: Request) async throws -> APIReminder {
        guard let id = req.parameters.get("id") else {
            throw Abort(.badRequest, reason: "Missing reminder ID")
        }
        let all = try await eventKitActor.fetchReminders()
        guard let found = all.first(where: { $0.id == id }) else {
            throw Abort(.notFound, reason: "Reminder not found.")
        }
        return found
    }
    
    // PUT /reminders/:id
    func updateReminder(_ req: Request) async throws -> APIReminder {
        guard let id = req.parameters.get("id") else {
            throw Abort(.badRequest, reason: "Missing reminder ID")
        }
        let data = try req.content.decode(APIReminder.self)
        return try await eventKitActor.updateReminder(id: id, with: data)
    }
    
    // DELETE /reminders/:id
    func deleteReminder(_ req: Request) async throws -> HTTPStatus {
        guard let id = req.parameters.get("id") else {
            throw Abort(.badRequest, reason: "Missing reminder ID")
        }
        try await eventKitActor.deleteReminder(id: id)
        return .noContent
    }
}
