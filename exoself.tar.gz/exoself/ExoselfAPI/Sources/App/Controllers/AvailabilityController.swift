import Vapor
import Foundation

///
/// AvailabilityController
///
/// 1) Gather busy intervals from events, merge them (union).
/// 2) Subtract busy from [globalStart, globalEnd).
/// 3) Optionally filter by working hours.
/// 4) Optionally intersect with user-provided ranges.
/// 5) Filter out intervals below `min_duration` in minutes.
/// 6) Return the final free intervals plus a day-by-day Markdown summary.
///
actor AvailabilityController: RouteCollection {
    // MARK: - Dependencies
    let eventKitActor: EventKitActor
    let userInfoService: UserInfoService
    
    private let debugLogPath = "/tmp/availability_debug.log"

    // MARK: - Initialization
    init(eventKitActor: EventKitActor, userInfoService: UserInfoService) {
        self.eventKitActor = eventKitActor
        self.userInfoService = userInfoService
    }

    // MARK: - Route Registration
    nonisolated func boot(routes: RoutesBuilder) throws {
        routes.grouped("availability").get(use: getAvailability)
    }

    // MARK: - Models
    struct IntersectRange: Codable {
        let start: Date
        let end: Date
    }

    struct AvailabilityResponse: Content {
        let ranges: [FreeInterval]
        let interpretation: String
    }

    struct FreeInterval: Content {
        let start: String
        let end: String
    }

    // MARK: - Handler
    func getAvailability(_ req: Request) async throws -> AvailabilityResponse {
        logDebug("\n\n=== [Availability Debug] New Request at \(Date()) ===\n")

        // 1) Parse basic query
        let iso = ISO8601DateFormatter()

        guard let startStr = req.query[String.self, at: "start"],
              let endStr   = req.query[String.self, at: "end"]
        else {
            logDebug("Missing 'start'/'end'.\n")
            throw Abort(.badRequest, reason: "Missing 'start'/'end'.")
        }
        logDebug("start=\(startStr)\nend=\(endStr)\n")

        guard let globalStart = iso.date(from: startStr),
              let globalEnd   = iso.date(from: endStr),
              globalEnd > globalStart
        else {
            logDebug("Could not parse start/end or end <= start.\n")
            throw Abort(.badRequest, reason: "Invalid start/end.")
        }
        logDebug("Parsed globalStart=\(globalStart), globalEnd=\(globalEnd)\n")

        // min_duration
        let minDurationStr: String? = req.query["min_duration"]
        let minDurationMinutes: Int? = minDurationStr.flatMap(Int.init)
        if let md = minDurationMinutes {
            logDebug("min_duration=\(md) minutes\n")
        } else {
            logDebug("No valid min_duration.\n")
        }

        // working_hours_only
        let whFlag = req.query[String.self, at: "working_hours_only"]?.lowercased()
        let workingHoursOnly = (whFlag == nil || whFlag == "true")
        logDebug("working_hours_only=\(workingHoursOnly)\n")

        // calendar_ids
        let calsParam = req.query[String.self, at: "calendar_ids"]
        let calendarIDs: [String]
        if let raw = calsParam, !raw.isEmpty {
            calendarIDs = raw.split(separator: ",").map(String.init)
        } else {
            calendarIDs = try await userInfoService.primaryCalendarIDs()
        }
        logDebug("calendar_ids=\(calendarIDs)\n")

        // 2) Decode intersect param
        let userIntersectRanges = try decodeIntersectRanges(req)
        logDebug("Final userIntersectRanges => \(userIntersectRanges)\n")

        // 3) Build busy intervals
        var busyIntervals = [Range<Date>]()
        for cid in calendarIDs {
            let events = try await eventKitActor.fetchEvents(
                start: globalStart,
                end: globalEnd,
                calendarID: cid
            )
            logDebug("Got \(events.count) events for cal=\(cid)\n")
            for e in events {
                logDebug("  event=\(e.id ?? ""), start=\(e.startTime), end=\(e.endTime), avail=\(e.availability ?? "nil")\n")
            }
            // Convert each event to a busy interval if not "free"
            for e in events {
                if e.availability?.lowercased() == "free" { continue }
                let (bs, be) = try localBounds(e)
                // clamp to [globalStart, globalEnd)
                let startC = max(bs, globalStart)
                let endC   = min(be, globalEnd)
                if endC > startC {
                    busyIntervals.append(startC..<endC)
                }
            }
        }

        // 4) Merge busy intervals
        let mergedBusy = buildUnion(busyIntervals)
        logDebug("Merged busy intervals =>\n")
        for (i, b) in mergedBusy.enumerated() {
            logDebug("  [\(i)] \(b.lowerBound) .. \(b.upperBound)\n")
        }

        // 5) Subtract from [globalStart, globalEnd)
        let globalInterval = [globalStart..<globalEnd]
        let freeIntervals = subtractIntervals(globalInterval, mergedBusy)
        logDebug("After subtract => free intervals =>\n")
        for (i, f) in freeIntervals.enumerated() {
            logDebug("  [\(i)] \(f.lowerBound) .. \(f.upperBound)\n")
        }

        // 6) working hours
        let whFiltered = workingHoursOnly ? applyWorkingHours(freeIntervals) : freeIntervals
        logDebug("After working hours =>\n")
        for (i, f) in whFiltered.enumerated() {
            logDebug("  [\(i)] \(f.lowerBound) .. \(f.upperBound)\n")
        }

        // 7) Intersect with user-provided ranges
        let finalIntersected: [Range<Date>]
        if userIntersectRanges.isEmpty {
            logDebug("No user intersection.\n")
            finalIntersected = whFiltered
        } else {
            let userUnion = buildUnion(userIntersectRanges.map { $0.start..<$0.end })
            logDebug("User union => \(userUnion)\n")
            finalIntersected = intersectIntervals(whFiltered, userUnion)
            logDebug("After intersection =>\n")
            for (i, f) in finalIntersected.enumerated() {
                logDebug("  [\(i)] \(f.lowerBound) .. \(f.upperBound)\n")
            }
        }

        // 8) Filter out intervals < min_duration
        let minFiltered = filterByMinDuration(finalIntersected, minDurationMinutes)
        logDebug("Result after min_duration =>\n")
        for (i, f) in minFiltered.enumerated() {
            logDebug("  [\(i)] \(f.lowerBound) .. \(f.upperBound)\n")
        }

        // 9) Convert final intervals to [FreeInterval]
        let iso2 = ISO8601DateFormatter()
        let finalFree = minFiltered.map {
            FreeInterval(start: iso2.string(from: $0.lowerBound),
                         end:   iso2.string(from: $0.upperBound))
        }

        // 10) Build interpretation
        let interpretation = buildMarkdown(finalFree)
        logDebug("Interpretation =>\n\(interpretation)\n")

        logDebug("=== [Availability Debug] End of request ===\n\n")

        return AvailabilityResponse(ranges: finalFree, interpretation: interpretation)
    }

    // MARK: - Decoding Intersect
    private func decodeIntersectRanges(_ req: Request) throws -> [IntersectRange] {
        // Try Vapor query decoding
        if let direct = try? req.query.get([IntersectRange].self, at: "intersect"),
           !direct.isEmpty {
            return direct
        }
        // Otherwise check raw
        if let raw = req.query[String.self, at: "intersect"], !raw.isEmpty {
            if let data = raw.data(using: .utf8) {
                let decoder = JSONDecoder()
                decoder.dateDecodingStrategy = .iso8601
                if let arr = try? decoder.decode([IntersectRange].self, from: data),
                   !arr.isEmpty {
                    return arr
                }
            }
        }
        return []
    }

    // MARK: - localBounds
    private func localBounds(_ evt: APIEvent) throws -> (Date, Date) {
        if !evt.allDay {
            if evt.endTime <= evt.startTime {
                return (evt.startTime, evt.startTime)
            }
            return (evt.startTime, evt.endTime)
        }
        // For allDay => interpret local day
        let tzID = userInfoService.primaryTimezone()
        guard let userTZ = TimeZone(identifier: tzID) else {
            throw Abort(.internalServerError, reason: "Invalid user tz for allDay event")
        }
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = userTZ

        let comps = cal.dateComponents([.year, .month, .day], from: evt.startTime)
        guard let y = comps.year, let m = comps.month, let d = comps.day else {
            return (evt.startTime, evt.startTime)
        }
        let dayStartLocal = cal.date(from: DateComponents(year: y, month: m, day: d, hour: 0))!
        guard let dayPlus1 = cal.date(byAdding: .day, value: 1, to: dayStartLocal) else {
            return (dayStartLocal, dayStartLocal)
        }
        return (dayStartLocal, dayPlus1)
    }

    // MARK: - Interval Ops
    /// Merge (union) intervals by sorting and merging overlaps.
    private func buildUnion(_ ranges: [Range<Date>]) -> [Range<Date>] {
        guard !ranges.isEmpty else { return [] }
        let sorted = ranges.sorted { $0.lowerBound < $1.lowerBound }
        var result = [Range<Date>]()
        var current = sorted[0]
        for i in 1..<sorted.count {
            let next = sorted[i]
            if next.lowerBound <= current.upperBound {
                let mergedEnd = max(current.upperBound, next.upperBound)
                current = current.lowerBound..<mergedEnd
            } else {
                result.append(current)
                current = next
            }
        }
        result.append(current)
        return result
    }

    /// Subtract sub from whole, returning the leftover intervals
    private func subtractIntervals(_ whole: [Range<Date>],
                                  _ sub: [Range<Date>]) -> [Range<Date>] {
        var result = whole
        for s in sub {
            var newResult = [Range<Date>]()
            for w in result {
                if w.upperBound <= s.lowerBound || w.lowerBound >= s.upperBound {
                    newResult.append(w) // no overlap
                } else {
                    // overlap => clip
                    if w.lowerBound < s.lowerBound {
                        newResult.append(w.lowerBound..<s.lowerBound)
                    }
                    if w.upperBound > s.upperBound {
                        newResult.append(s.upperBound..<w.upperBound)
                    }
                }
            }
            result = newResult
        }
        return result
    }

    /// Intersect two sets of intervals
    private func intersectIntervals(_ a: [Range<Date>], _ b: [Range<Date>]) -> [Range<Date>] {
        var ans = [Range<Date>]()
        let arrA = a.sorted { $0.lowerBound < $1.lowerBound }
        let arrB = b.sorted { $0.lowerBound < $1.lowerBound }
        var i = 0, j = 0
        while i < arrA.count && j < arrB.count {
            let x = arrA[i]
            let y = arrB[j]
            let start = max(x.lowerBound, y.lowerBound)
            let end = min(x.upperBound, y.upperBound)
            if end > start {
                ans.append(start..<end)
            }
            if x.upperBound < y.upperBound { i += 1 }
            else { j += 1 }
        }
        return ans
    }

    // MARK: - Working Hours
    /// Keep only [7..18) on weekdays
    private func applyWorkingHours(_ intervals: [Range<Date>]) -> [Range<Date>] {
        let tzID = userInfoService.primaryTimezone()
        guard let userTZ = TimeZone(identifier: tzID) else {
            logDebug("Invalid tz => \(tzID)\n")
            return []
        }
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = userTZ

        var result = [Range<Date>]()
        for r in intervals {
            var cursor = r.lowerBound
            while cursor < r.upperBound {
                let dayStart = cal.startOfDay(for: cursor)
                guard let dayEnd = cal.date(byAdding: .day, value: 1, to: dayStart) else {
                    break
                }
                let localStart = max(r.lowerBound, dayStart)
                let localEnd   = min(r.upperBound, dayEnd)

                // weekday?
                let wday = cal.component(.weekday, from: localStart)
                if wday != 1 && wday != 7 {
                    let day7  = cal.date(bySettingHour: 7, minute: 0, second: 0, of: dayStart)!
                    let day18 = cal.date(bySettingHour: 18, minute: 0, second: 0, of: dayStart)!
                    let whStart = max(localStart, day7)
                    let whEnd   = min(localEnd, day18)
                    if whEnd > whStart {
                        result.append(whStart..<whEnd)
                    }
                }
                cursor = dayEnd
            }
        }
        return result
    }

    // MARK: - Min Duration
    private func filterByMinDuration(_ intervals: [Range<Date>],
                                     _ minMinutes: Int?) -> [Range<Date>] {
        guard let m = minMinutes, m > 0 else {
            return intervals
        }
        let cutoff = TimeInterval(m * 60)
        return intervals.filter { ($0.upperBound.timeIntervalSince($0.lowerBound) >= cutoff) }
    }

    // MARK: - Markdown
    private func buildMarkdown(_ freeSlots: [FreeInterval]) -> String {
        if freeSlots.isEmpty {
            return "No availability.\n"
        }
        let tzID = userInfoService.primaryTimezone()
        guard let userTZ = TimeZone(identifier: tzID) else {
            return "Error: invalid user timezone.\n"
        }
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = userTZ

        struct DayKey: Hashable, Comparable {
            let year: Int
            let month: Int
            let day: Int
            static func < (lhs: DayKey, rhs: DayKey) -> Bool {
                if lhs.year != rhs.year { return lhs.year < rhs.year }
                if lhs.month != rhs.month { return lhs.month < rhs.month }
                return lhs.day < rhs.day
            }
        }

        let iso = ISO8601DateFormatter()
        var dayMap = [DayKey: [(Date, Date)]]()

        for slot in freeSlots {
            guard let s = iso.date(from: slot.start),
                  let e = iso.date(from: slot.end),
                  e > s
            else { continue }

            let comps = cal.dateComponents([.year, .month, .day], from: s)
            guard let yy = comps.year, let mm = comps.month, let dd = comps.day else { continue }
            let key = DayKey(year: yy, month: mm, day: dd)
            dayMap[key, default: []].append((s, e))
        }

        let dayFormatter = DateFormatter()
        dayFormatter.dateFormat = "EEEE, MMMM d, yyyy"
        dayFormatter.timeZone = userTZ

        let timeFormatter = DateFormatter()
        timeFormatter.dateFormat = "h:mm a"
        timeFormatter.timeZone = userTZ
        let zoneAbbrev = userTZ.abbreviation() ?? "Local"

        let sortedKeys = dayMap.keys.sorted()
        var md = ""
        for (idx, key) in sortedKeys.enumerated() {
            guard let dayDate = cal.date(from: DateComponents(year: key.year, month: key.month, day: key.day, hour: 12))
            else { continue }
            let dayString = dayFormatter.string(from: dayDate)
            md += "### \(dayString)\n"

            let intervals = dayMap[key]!.sorted { $0.0 < $1.0 }
            for (start, end) in intervals {
                let sStr = timeFormatter.string(from: start)
                let eStr = timeFormatter.string(from: end)
                md += " - \(sStr) \(zoneAbbrev) - \(eStr) \(zoneAbbrev)\n"
            }
            if idx < sortedKeys.count - 1 {
                md += "\n"
            }
        }
        return md
    }

    // MARK: - Logging
    private func logDebug(_ message: String) {
        let fileURL = URL(fileURLWithPath: debugLogPath)
        do {
            if FileManager.default.fileExists(atPath: debugLogPath) {
                let handle = try FileHandle(forWritingTo: fileURL)
                try handle.seekToEnd()
                if let data = message.data(using: .utf8) {
                    handle.write(data)
                }
                try handle.close()
            } else {
                try message.write(to: fileURL, atomically: true, encoding: .utf8)
            }
        } catch {
            print("Error writing to debug log: \(error)")
        }
    }
}
