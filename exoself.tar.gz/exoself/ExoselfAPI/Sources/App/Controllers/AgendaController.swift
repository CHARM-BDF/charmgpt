import Vapor
import Foundation

struct AgendaController: RouteCollection {
    let eventKitActor: EventKitActor
    let userInfoService: UserInfoService

    func boot(routes: RoutesBuilder) throws {
        routes.get("agenda", use: getAgenda)
    }

    /// The final response structure for GET /agenda.
    /// "events": the array of APIEvent
    /// "interpretation": day-by-day markdown summary.
    struct AgendaResponse: Content {
        let events: [APIEvent]
        let interpretation: String
    }
    
    // =========================================
    // MARK: - NEW: helpers for notes_length
    // =========================================
    
    /// Parse ?notes_length=...
    ///   - If absent => 100 (default)
    ///   - If "all" => return nil (no truncation)
    ///   - If a positive integer => that many chars
    ///   - If invalid => 100
    private func parseNotesLimit(from req: Request) -> Int? {
        guard let raw = req.query[String.self, at: "notes_length"] else {
            return 100  // default if missing
        }
        if raw.lowercased() == "all" {
            return nil  // no truncation
        }
        if let val = Int(raw), val > 0 {
            return val
        }
        return 100  // fallback if invalid
    }
    
    /// Truncate the event's notes if needed
    private func truncateNotes(_ notes: String?, limit: Int?) -> String? {
        guard let notes = notes else { return nil }
        // nil limit => "all" => return as-is
        guard let limit = limit else {
            return notes
        }
        return (notes.count > limit)
            ? String(notes.prefix(limit))
            : notes
    }
    
    // =========================================
    // MARK: - GET /agenda
    // =========================================
    func getAgenda(_ req: Request) async throws -> AgendaResponse {
        // 1) figure out the user's local time zone
        let tzID = userInfoService.primaryTimezone()
        guard let tz = TimeZone(identifier: tzID) else {
            throw Abort(.internalServerError, reason: "Invalid primary timezone: \(tzID)")
        }

        let dayParam: String? = req.query["days"]
        let dayFormatter = DateFormatter()
        dayFormatter.dateFormat = "yyyy-MM-dd"
        dayFormatter.timeZone = tz

        let now = Date()
        let defaultDayString = dayFormatter.string(from: now)  // e.g. "2025-03-01"

        // 2) If `days` is present, parse that into a set/list of days
        let parsedDays: [Date]
        if let dp = dayParam, !dp.isEmpty {
            parsedDays = try parseDaysParam(dp, using: dayFormatter)
        } else {
            // If `days` is NOT present, fall back to `start`/`end`
            let startStr: String? = req.query["start"]
            let endStr:   String? = req.query["end"]

            let s = startStr ?? defaultDayString
            let e = endStr   ?? s

            guard let startDay = dayFormatter.date(from: s),
                  let endDay   = dayFormatter.date(from: e)
            else {
                throw Abort(.badRequest, reason: "Invalid date format. Use yyyy-MM-dd.")
            }
            parsedDays = daysBetween(startDay, endDay, calendar: .current)
        }

        guard !parsedDays.isEmpty else {
            return AgendaResponse(
                events: [],
                interpretation: "No valid days requested."
            )
        }

        // We'll fetch from the earliest to the latest
        let earliestDay = parsedDays.first!
        let latestDay   = parsedDays.last!

        guard let finalEnd = Calendar.current.date(byAdding: .day, value: 1, to: latestDay) else {
            throw Abort(.internalServerError, reason: "Could not add 1 day to the final day.")
        }

        // parse optional calendar_ids
        let calsParam: String? = req.query["calendar_ids"]
        let calendarIDs: [String]
        if let rawCals = calsParam, !rawCals.isEmpty {
            calendarIDs = rawCals.split(separator: ",").map(String.init)
        } else {
            // fallback to user’s primaryCalendarIDs
            calendarIDs = try await userInfoService.primaryCalendarIDs()
        }

        // 4) fetch all events from earliestDay..finalEnd
        var combinedEvents = [APIEvent]()
        for cid in calendarIDs {
            let events = try await eventKitActor.fetchEvents(
                start: earliestDay,
                end: finalEnd,
                calendarID: cid
            )
            combinedEvents.append(contentsOf: events)
        }

        // 5) sort them by start time
        combinedEvents.sort { $0.startTime < $1.startTime }

        // =========================================
        // 6) NEW: truncate notes if needed
        // =========================================
        let notesLimit = parseNotesLimit(from: req)
        combinedEvents = combinedEvents.map { evt in
            var copy = evt
            copy.notes = truncateNotes(evt.notes, limit: notesLimit)
            return copy
        }
        
        // 7) build the day-by-day "interpretation" in local time
        let daySet = Set(parsedDays.map { dateToKey($0, timeZone: tz) })
        let interpretation = buildAgendaInterpretation(
            events: combinedEvents,
            userTZ: tz,
            allowedDayKeys: daySet
        )

        // 8) return AgendaResponse
        return AgendaResponse(events: combinedEvents, interpretation: interpretation)
    }

    // ===============================
    // parseDaysParam, buildAgendaInterpretation, daysBetween
    // (unchanged from your original)
    // ===============================
    private func parseDaysParam(_ param: String, using formatter: DateFormatter) throws -> [Date] {
        if param.contains("..") {
            let parts = param.split(separator: "..", maxSplits: 1).map(String.init)
            guard parts.count == 2 else {
                throw Abort(.badRequest, reason: "Invalid days range format.")
            }
            guard let startDate = formatter.date(from: parts[0]),
                  let endDate   = formatter.date(from: parts[1])
            else {
                throw Abort(.badRequest, reason: "Invalid date format. Use yyyy-MM-dd.")
            }
            return daysBetween(startDate, endDate, calendar: .current)
        } else if param.contains(",") {
            let pieces = param.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }
            var results = [Date]()
            for p in pieces {
                guard let d = formatter.date(from: p) else {
                    throw Abort(.badRequest, reason: "Invalid date format. Use yyyy-MM-dd.")
                }
                results.append(d)
            }
            return results.sorted()
        } else {
            guard let single = formatter.date(from: param) else {
                throw Abort(.badRequest, reason: "Invalid date format. Use yyyy-MM-dd.")
            }
            return [single]
        }
    }

    private func buildAgendaInterpretation(
        events: [APIEvent],
        userTZ: TimeZone,
        allowedDayKeys: Set<DateOnlyKey> = []
    ) -> String {
        guard !events.isEmpty else {
            return "No events."
        }

        var localCal = Calendar(identifier: .gregorian)
        localCal.timeZone = userTZ

        var dayBuckets = [DateOnlyKey: [APIEvent]]()
        for ev in events {
            let comps = localCal.dateComponents([.year, .month, .day], from: ev.startTime)
            guard let y = comps.year, let m = comps.month, let d = comps.day else { continue }
            let key = DateOnlyKey(year: y, month: m, day: d)
            dayBuckets[key, default: []].append(ev)
        }

        let sortedKeys = dayBuckets.keys.sorted()
        let dayFormatter = DateFormatter()
        dayFormatter.dateFormat = "EEEE, MMMM d yyyy"
        dayFormatter.timeZone = userTZ

        let timeFormatter = DateFormatter()
        timeFormatter.dateFormat = "h:mm a z"
        timeFormatter.timeZone = userTZ

        var md = ""
        var displayedAny = false

        for (idx, k) in sortedKeys.enumerated() {
            if !allowedDayKeys.isEmpty && !allowedDayKeys.contains(k) {
                continue
            }
            guard let dayDate = localCal.date(from: DateComponents(year: k.year, month: k.month, day: k.day, hour: 12))
            else { continue }

            let dayString = dayFormatter.string(from: dayDate)
            md += "\(dayString):\n"

            let evs = (dayBuckets[k] ?? []).sorted { $0.startTime < $1.startTime }
            for e in evs {
                let st = timeFormatter.string(from: e.startTime)
                md += " - \(st)  \(e.title) (\(e.calendarID))\n"
            }

            if idx < sortedKeys.count - 1 {
                md += "\n"
            }
            displayedAny = true
        }

        if !displayedAny {
            return "No events on the requested days."
        }
        return md
    }

    private func daysBetween(_ start: Date, _ end: Date, calendar: Calendar) -> [Date] {
        let compare = calendar.compare(start, to: end, toGranularity: .day)
        if compare == .orderedDescending {
            return []
        }
        var result = [Date]()
        var current = calendar.startOfDay(for: start)
        let endOfDay = calendar.startOfDay(for: end)
        while current <= endOfDay {
            result.append(current)
            guard let next = calendar.date(byAdding: .day, value: 1, to: current) else { break }
            current = next
        }
        return result
    }

    /// A small struct for day-based dictionary keys
    private struct DateOnlyKey: Hashable, Comparable {
        let year: Int
        let month: Int
        let day: Int
        static func < (lhs: DateOnlyKey, rhs: DateOnlyKey) -> Bool {
            if lhs.year != rhs.year { return lhs.year < rhs.year }
            if lhs.month != rhs.month { return lhs.month < rhs.month }
            return lhs.day < rhs.day
        }
    }

    private func dateToKey(_ d: Date, timeZone: TimeZone) -> DateOnlyKey {
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = timeZone
        let comps = cal.dateComponents([.year, .month, .day], from: d)
        return DateOnlyKey(
            year: comps.year ?? 0,
            month: comps.month ?? 0,
            day: comps.day ?? 0
        )
    }
}
