import Vapor
@preconcurrency import EventKit  // if needed to suppress concurrency warnings

struct CalendarController: RouteCollection {
    let eventKitActor: EventKitActor
    
    func boot(routes: RoutesBuilder) throws {
        let calendars = routes.grouped("calendars")
        calendars.get(use: getAllCalendars)
        calendars.post(use: createCalendar)
        calendars.group(":id") { cal in
            cal.get(use: getCalendar)
            cal.put(use: updateCalendar) // not fully implemented
            cal.delete(use: deleteCalendar)
        }
    }
    
    // GET /calendars
    func getAllCalendars(_ req: Request) async throws -> [APICalendar] {
        try await eventKitActor.fetchCalendars()
    }
    
    // POST /calendars
    func createCalendar(_ req: Request) async throws -> APICalendar {
        struct Input: Content { let name: String }
        let input = try req.content.decode(Input.self)
        return try await eventKitActor.createCalendar(named: input.name)
    }
    
    // GET /calendars/:id
    func getCalendar(_ req: Request) async throws -> APICalendar {
        guard let id = req.parameters.get("id") else {
            throw Abort(.badRequest, reason: "Missing calendar ID")
        }
        guard let cal = await eventKitActor.calendar(withIdentifier: id) else {
            throw Abort(.notFound, reason: "Calendar not found.")
        }
        return cal
    }
    
    // PUT /calendars/:id
    func updateCalendar(_ req: Request) async throws -> APICalendar {
        throw Abort(.notImplemented, reason: "Updating event calendar not implemented.")
    }
    
    // DELETE /calendars/:id
    func deleteCalendar(_ req: Request) async throws -> HTTPStatus {
        guard let id = req.parameters.get("id") else {
            throw Abort(.badRequest, reason: "Missing calendar ID")
        }
        try await eventKitActor.deleteCalendar(id: id)
        return .noContent
    }
}
