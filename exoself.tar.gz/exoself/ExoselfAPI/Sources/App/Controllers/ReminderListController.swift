import Vapor
@preconcurrency import EventKit  // if needed

struct ReminderListController: RouteCollection {
    let eventKitActor: EventKitActor
    
    func boot(routes: RoutesBuilder) throws {
        // e.g., /reminder-lists
        let lists = routes.grouped("reminder-lists")
        lists.get(use: getAllLists)
        lists.post(use: createList)
    }
    
    // GET /reminder-lists
    func getAllLists(_ req: Request) async throws -> [APIReminderList] {
        // Must use `await` because eventKitActor is an actor
        return await eventKitActor.fetchReminderLists()
    }
    
    // POST /reminder-lists
    // Body: { "name": "Errands" }
    func createList(_ req: Request) async throws -> APIReminderList {
        struct Input: Content { let name: String }
        let input = try req.content.decode(Input.self)
        return try await eventKitActor.createReminderList(named: input.name)
    }
}
