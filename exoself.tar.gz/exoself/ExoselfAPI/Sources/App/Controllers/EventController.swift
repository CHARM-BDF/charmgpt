import Vapor
@preconcurrency import EventKit  // if needed to suppress concurrency warnings

struct EventController: RouteCollection {
    /// A reference to your concurrency-safe actor for event operations.
    let eventKitActor: EventKitActor
    
    // Register routes
    func boot(routes: RoutesBuilder) throws {
        let events = routes.grouped("events")

        events.get(use: self.getAllEvents)
        events.post(use: self.createEvent)
        
        events.group(":id") { ev in
            ev.get(use: self.getEvent)
            ev.put(use: self.updateEvent)
            ev.delete(use: self.deleteEvent)
        }
    }

    // MARK: - Helper for notes_length
    
    /// Parses the `notes_length` query param. 
    ///  - If absent, returns 100 (default).
    ///  - If "all", returns nil to indicate "no truncation."
    ///  - If a positive integer string, returns that integer.
    ///  - If invalid, also defaults to 100.
    private func parseNotesLimit(from req: Request) -> Int? {
        // e.g. ?notes_length=all  => nil
        // e.g. ?notes_length=50   => 50
        // e.g. (missing)          => 100
        // e.g. (invalid)          => 100
        guard let raw = req.query[String.self, at: "notes_length"] else {
            return 100  // default if missing
        }
        if raw.lowercased() == "all" {
            return nil  // no truncation
        }
        if let val = Int(raw), val > 0 {
            return val
        }
        return 100  // fallback if invalid
    }
    
    /// Truncates the given string to `limit` characters, unless `limit == nil`,
    /// which means "no truncation."
    private func truncateNotes(_ notes: String?, limit: Int?) -> String? {
        guard let notes = notes else { return nil }
        // nil limit => "all" => return as-is
        guard let limit = limit else { return notes }
        if notes.count > limit {
            return String(notes.prefix(limit))
        }
        return notes
    }

    // MARK: - 1) GET /events (list all events)
    
    @Sendable
    func getAllEvents(_ req: Request) async throws -> [APIEvent] {
        // -- parse new notes_length param --
        let notesLimit = parseNotesLimit(from: req)
        
        // existing filters:
        let calID: String?    = req.query["calendar_id"]
        let startStr: String? = req.query["start_after"]
        let endStr:   String? = req.query["end_before"]
        
        let titleRaw: String? = req.query["title_contains"]
        let notesRaw: String? = req.query["notes_contains"]
        let titleSub = titleRaw?.lowercased()
        let notesSub = notesRaw?.lowercased()
        
        let withinSecs: Int?  = req.query["within_seconds"]
        let beforeTimeStr: String? = req.query["before_time"]
        let afterTimeStr:  String? = req.query["after_time"]
        
        let iso = ISO8601DateFormatter()
        let startDate = startStr.flatMap { iso.date(from: $0) }
        let endDate   = endStr.flatMap   { iso.date(from: $0) }
        let beforeTime = beforeTimeStr.flatMap { iso.date(from: $0) }
        let afterTime  = afterTimeStr.flatMap  { iso.date(from: $0) }
        
        // If within_seconds is set, interpret that as a range from now
        let now = Date()
        var withinRange: (Date, Date)? = nil
        if let secs = withinSecs {
            if secs >= 0 {
                withinRange = (now, now.addingTimeInterval(TimeInterval(secs)))
            } else {
                // negative => range is (now + secs, now)
                withinRange = (now.addingTimeInterval(TimeInterval(secs)), now)
            }
        }
        
        // 1) Fetch from EventKit
        var allEvents = try await eventKitActor.fetchEvents(
            start: startDate,
            end: endDate,
            calendarID: calID
        )
        
        // 2) Filter in memory
        allEvents = allEvents.filter { evt in
            // a) Title/Notes substring filters
            if let tSub = titleSub,
               !evt.title.lowercased().contains(tSub)
            {
                return false
            }
            if let nSub = notesSub {
                let noteText = (evt.notes ?? "").lowercased()
                if !noteText.contains(nSub) {
                    return false
                }
            }
            
            // b) Overlapping with time intervals
            func overlapsRange(_ s: Date, _ e: Date, _ rngStart: Date, _ rngEnd: Date) -> Bool {
                // Overlap if start < rngEnd AND end > rngStart
                return (s < rngEnd) && (e > rngStart)
            }
            
            if let (wStart, wEnd) = withinRange {
                if !overlapsRange(evt.startTime, evt.endTime, wStart, wEnd) {
                    return false
                }
            }
            
            if let at = afterTime, let bt = beforeTime {
                if !overlapsRange(evt.startTime, evt.endTime, at, bt) {
                    return false
                }
            } else if let at = afterTime {
                if evt.endTime <= at {
                    return false
                }
            } else if let bt = beforeTime {
                if evt.startTime >= bt {
                    return false
                }
            }
            
            // pass all filters
            return true
        }
        
        // 3) Truncate notes if needed
        allEvents = allEvents.map { original in
            var copy = original
            copy.notes = truncateNotes(original.notes, limit: notesLimit)
            return copy
        }
        
        return allEvents
    }

    // MARK: - 2) POST /events
    
    @Sendable
    func createEvent(_ req: Request) async throws -> APIEvent {
        let data = try req.content.decode(APIEvent.self)
        return try await eventKitActor.createEvent(data)
    }
    
    // MARK: - 3) GET /events/:id
    
    @Sendable
    func getEvent(_ req: Request) async throws -> APIEvent {
        guard let id = req.parameters.get("id") else {
            throw Abort(.badRequest, reason: "Missing event ID")
        }
        guard let found = await eventKitActor.event(withIdentifier: id) else {
            throw Abort(.notFound, reason: "Event not found.")
        }

        // -- parse new notes_length param --
        let notesLimit = parseNotesLimit(from: req)

        // Truncate the event's notes if necessary
        var final = found
        final.notes = truncateNotes(found.notes, limit: notesLimit)
        return final
    }
    
    // MARK: - 4) PUT /events/:id
    
    @Sendable
    func updateEvent(_ req: Request) async throws -> APIEvent {
        guard let id = req.parameters.get("id") else {
            throw Abort(.badRequest, reason: "Missing event ID")
        }
        var data = try req.content.decode(APIEvent.self)
        // Force the path ID, and ensure we include calendarName
        data = APIEvent(
            id: id,
            calendarID: data.calendarID,
            calendarName: data.calendarName,
            title: data.title,
            startTime: data.startTime,
            endTime: data.endTime,
            allDay: data.allDay,
            location: data.location,
            notes: data.notes,
            recurrenceRule: data.recurrenceRule,
            availability: data.availability
        )
        
        return try await eventKitActor.updateEvent(id: id, with: data)
    }
    
    // MARK: - 5) DELETE /events/:id
    
    @Sendable
    func deleteEvent(_ req: Request) async throws -> HTTPStatus {
        guard let id = req.parameters.get("id") else {
            throw Abort(.badRequest, reason: "Missing event ID")
        }
        try await eventKitActor.deleteEvent(id: id)
        return .noContent
    }
}
