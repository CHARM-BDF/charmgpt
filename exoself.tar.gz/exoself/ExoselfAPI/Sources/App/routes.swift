// Sources/App/routes.swift

import Vapor

func routes(_ app: Application) throws {
    // 1) Read environment variables
    let basePath = Environment.get("BASE_URL") ?? "api/exoself"
    let apiKey = Environment.get("API_KEY") ?? "mysecret"  // or retrieve from a config file
    
    // 2) Create the Actor / Service
    let eventKitActor = EventKitActor()

    let configService = try UserConfigService(app: app)
    let userInfoService = UserInfoService(app: app, configService: configService, eventKitActor: eventKitActor)

    // 3) Create authentication middleware instance
    let apiKeyMiddleware = APIKeyAuthMiddleware(validToken: apiKey)
    
    // 4) Group all routes under the base path & secure them
    let baseComponents = basePath
        .split(separator: "/")
        .map(String.init)
        .map(PathComponent.init)

    let securedGroup = app.grouped(baseComponents).grouped(apiKeyMiddleware)

    // ------------------------------------------------------------
    // 5) Register controllers
    // ------------------------------------------------------------
    
    // CALENDARS
    let calendarController = CalendarController(eventKitActor: eventKitActor)
    try securedGroup.register(collection: calendarController)
    
    // EVENTS
    let eventController = EventController(eventKitActor: eventKitActor)
    try securedGroup.register(collection: eventController)
    
    // REMINDERS
    let reminderController = ReminderController(eventKitActor: eventKitActor)
    try securedGroup.register(collection: reminderController)

    let reminderListController = ReminderListController(eventKitActor: eventKitActor)
    try securedGroup.register(collection: reminderListController)

    // AVAILABILITY
    let availabilityController = AvailabilityController(eventKitActor: eventKitActor, userInfoService: userInfoService)
    try securedGroup.register(collection: availabilityController)

    // AGENDA
    let agendaController = AgendaController(eventKitActor: eventKitActor, userInfoService: userInfoService)
    try securedGroup.register(collection: agendaController)

    // ------------------------------------------------------------
    // 6) Register the new /user route group
    // ------------------------------------------------------------
    let userController = UserController(userInfoService: userInfoService)
    // Example final paths: /api/exoself/user, /api/exoself/user/about, etc.
    let userGroup = securedGroup.grouped("user")
    try userGroup.register(collection: userController)
}