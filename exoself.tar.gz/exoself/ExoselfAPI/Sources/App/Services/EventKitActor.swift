//
//  EventKitActor.swift
//
//  Concurrency-safe wrapper around EKEventStore.
//  Ensures we only access EventKit from one place to avoid data races or concurrency issues.
//
//  UPDATED to include `calendarName` in `APIEvent`
//  and `listName` in `APIReminder`.
//

@preconcurrency import EventKit
import Foundation
import Vapor

/// If Swift concurrency complains about passing `[EKReminder]`, you could uncomment:
/// extension EKReminder: @unchecked Sendable {}
///
/// This is an actor because we only want one concurrency domain managing EKEventStore
/// to prevent data races or concurrency issues with EventKit.
actor EventKitActor {
    // --------------------------------------------------
    // The EventKit "store" is how we read/write calendars, events, reminders.
    // --------------------------------------------------
    private let store = EKEventStore()

    // MARK: - Initialization
    init() {
        // Request access to events & reminders as soon as this actor is created.
        Task {
            do {
                try await requestEventAccess()
                try await requestReminderAccess()
            } catch {
                print("Error requesting EventKit access: \(error)")
            }
        }
    }

    // --------------------------------------------------
    // MARK: - Request Access
    // --------------------------------------------------

    /// Request permission to access Events in EventKit.
    private func requestEventAccess() async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            store.requestAccess(to: .event) { granted, error in
                if let err = error {
                    cont.resume(throwing: err)
                } else if !granted {
                    cont.resume(
                        throwing: Abort(.unauthorized, reason: "Event calendar access not granted.")
                    )
                } else {
                    cont.resume(returning: ())
                }
            }
        }
    }

    /// Request permission to access Reminders in EventKit.
    private func requestReminderAccess() async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            store.requestAccess(to: .reminder) { granted, error in
                if let err = error {
                    cont.resume(throwing: err)
                } else if !granted {
                    cont.resume(
                        throwing: Abort(.unauthorized, reason: "Reminder access not granted.")
                    )
                } else {
                    cont.resume(returning: ())
                }
            }
        }
    }

    // --------------------------------------------------
    // MARK: - Utility checks
    // --------------------------------------------------
    private func isEventCalendar(_ cal: EKCalendar) -> Bool {
        store.calendars(for: .event).contains(cal)
    }
    private func isReminderCalendar(_ cal: EKCalendar) -> Bool {
        store.calendars(for: .reminder).contains(cal)
    }

    // --------------------------------------------------
    // MARK: - Fetch / Create / Delete Event Calendars
    // --------------------------------------------------

    /// Fetch all event-type calendars and return them as `[APICalendar]`.
    func fetchCalendars() async throws -> [APICalendar] {
        let cals = store.calendars(for: .event)
        return cals.map { cal in
            APICalendar(
                id: cal.calendarIdentifier,
                name: cal.title,
                isDefault: false
            )
        }
    }

    /// Create a new event-type calendar with the specified `name`.
    func createCalendar(named name: String) async throws -> APICalendar {
        let cal = EKCalendar(for: .event, eventStore: store)
        cal.title = name

        guard let localSource =
            store.sources.first(where: { $0.sourceType == .local })
            ?? store.defaultCalendarForNewEvents?.source
        else {
            throw Abort(.internalServerError, reason: "No local source found for event calendar.")
        }
        cal.source = localSource

        try store.saveCalendar(cal, commit: true)
        return APICalendar(
            id: cal.calendarIdentifier,
            name: cal.title,
            isDefault: false
        )
    }

    /// Delete an event-type calendar by ID.
    func deleteCalendar(id: String) async throws {
        guard let cal = store.calendar(withIdentifier: id),
              isEventCalendar(cal)
        else {
            throw Abort(.notFound, reason: "Event calendar not found.")
        }
        try store.removeCalendar(cal, commit: true)
    }

    /// Return a single APICalendar by ID, if found and it's an event calendar.
    func calendar(withIdentifier id: String) async -> APICalendar? {
        guard let cal = store.calendar(withIdentifier: id),
              isEventCalendar(cal)
        else {
            return nil
        }
        return APICalendar(
            id: cal.calendarIdentifier,
            name: cal.title,
            isDefault: false
        )
    }

    // --------------------------------------------------
    // MARK: - Events
    // --------------------------------------------------

    /// Fetch events in the optional [start, end] range.
    /// If `calendarID` is provided, fetch from that single calendar.
    func fetchEvents(start: Date?, end: Date?, calendarID: String?) async throws -> [APIEvent] {
        // 1) Determine which EKCalendar(s) to query
        let cals: [EKCalendar]
        if let calID = calendarID,
           let specific = store.calendar(withIdentifier: calID),
           isEventCalendar(specific) {
            cals = [specific]
        } else {
            cals = store.calendars(for: .event)
        }

        // 2) Build a predicate for the time window
        let startDate = start ?? Date().addingTimeInterval(-7 * 24 * 3600)
        let endDate   = end   ?? Date().addingTimeInterval(+7 * 24 * 3600)
        let predicate = store.predicateForEvents(
            withStart: startDate,
            end: endDate,
            calendars: cals
        )

        // 3) Grab matching EKEvents
        let ekEvents = store.events(matching: predicate)

        // 4) Convert each EKEvent into an APIEvent, ensuring .tentative or .canceled
        //    statuses override the default availability so that they block time properly.
        return ekEvents.map { e in
            // -- NEW FIX: override e.availability based on e.status if needed --
            var finalAvail = e.availability
            switch e.status {
            case .canceled:
                finalAvail = .free
            case .tentative:
                finalAvail = .tentative
            case .confirmed:
                // If iCal status is confirmed but e.availability might be .free => treat as busy
                if finalAvail == .free {
                    finalAvail = .busy
                }
            default:
                break
            }

            return APIEvent(
                id: e.eventIdentifier ?? "",
                calendarID: e.calendar.calendarIdentifier,
                calendarName: e.calendar.title,  // <-- Include the calendar's title
                title: e.title,
                startTime: e.startDate,
                endTime: e.endDate,
                allDay: e.isAllDay,
                location: e.location,
                notes: e.notes,
                recurrenceRule: nil,
                availability: availabilityString(for: finalAvail)
            )
        }
    }

    /// Create a new event from an `APIEvent`.
    func createEvent(_ data: APIEvent) async throws -> APIEvent {
        guard let cal = store.calendar(withIdentifier: data.calendarID),
              isEventCalendar(cal)
        else {
            throw Abort(.notFound, reason: "Event calendar not found.")
        }

        let ekEvent = EKEvent(eventStore: store)
        ekEvent.calendar  = cal
        ekEvent.title     = data.title
        ekEvent.startDate = data.startTime
        ekEvent.endDate   = data.endTime
        ekEvent.isAllDay  = data.allDay
        ekEvent.location  = data.location
        ekEvent.notes     = data.notes
        ekEvent.availability = parseAvailability(data.availability)

        try store.save(ekEvent, span: .thisEvent, commit: true)

        // Return the newly created event in our API model, with calendar name
        return APIEvent(
            id: ekEvent.eventIdentifier ?? "",
            calendarID: cal.calendarIdentifier,
            calendarName: cal.title,
            title: ekEvent.title,
            startTime: ekEvent.startDate,
            endTime: ekEvent.endDate,
            allDay: ekEvent.isAllDay,
            location: ekEvent.location,
            notes: ekEvent.notes,
            recurrenceRule: nil,
            availability: availabilityString(for: ekEvent.availability)
        )
    }

    /// Update an existing event by ID with new data.
    func updateEvent(id: String, with data: APIEvent) async throws -> APIEvent {
        guard let ekEvent = store.event(withIdentifier: id) else {
            throw Abort(.notFound, reason: "Event not found.")
        }

        ekEvent.title     = data.title
        ekEvent.startDate = data.startTime
        ekEvent.endDate   = data.endTime
        ekEvent.isAllDay  = data.allDay
        ekEvent.location  = data.location
        ekEvent.notes     = data.notes
        ekEvent.availability = parseAvailability(data.availability)

        try store.save(ekEvent, span: .thisEvent, commit: true)

        return APIEvent(
            id: ekEvent.eventIdentifier ?? "",
            calendarID: ekEvent.calendar.calendarIdentifier,
            calendarName: ekEvent.calendar.title,
            title: ekEvent.title,
            startTime: ekEvent.startDate,
            endTime: ekEvent.endDate,
            allDay: ekEvent.isAllDay,
            location: ekEvent.location,
            notes: ekEvent.notes,
            recurrenceRule: nil,
            availability: availabilityString(for: ekEvent.availability)
        )
    }

    /// Delete an event by ID if it exists.
    func deleteEvent(id: String) async throws {
        guard let ekEvent = store.event(withIdentifier: id) else {
            throw Abort(.notFound, reason: "Event not found.")
        }
        try store.remove(ekEvent, span: .thisEvent, commit: true)
    }

    /// Return a single `APIEvent` by ID if found.
    func event(withIdentifier id: String) async -> APIEvent? {
        guard let ekEvent = store.event(withIdentifier: id) else {
            return nil
        }
        return APIEvent(
            id: ekEvent.eventIdentifier ?? "",
            calendarID: ekEvent.calendar.calendarIdentifier,
            calendarName: ekEvent.calendar.title,
            title: ekEvent.title,
            startTime: ekEvent.startDate,
            endTime: ekEvent.endDate,
            allDay: ekEvent.isAllDay,
            location: ekEvent.location,
            notes: ekEvent.notes,
            recurrenceRule: nil,
            availability: availabilityString(for: ekEvent.availability)
        )
    }

    // --------------------------------------------------
    // MARK: - Reminders
    // --------------------------------------------------

    func fetchReminderLists() async -> [APIReminderList] {
        let rCals = store.calendars(for: .reminder)
        return rCals.map { cal in
            APIReminderList(
                id: cal.calendarIdentifier,
                name: cal.title,
                isDefault: false
            )
        }
    }

    func createReminderList(named name: String) async throws -> APIReminderList {
        let cal = EKCalendar(for: .reminder, eventStore: store)
        cal.title = name

        guard let localSource =
            store.sources.first(where: { $0.sourceType == .local })
            ?? store.defaultCalendarForNewReminders()?.source
        else {
            throw Abort(.internalServerError, reason: "No valid source found for reminder lists.")
        }
        cal.source = localSource

        try store.saveCalendar(cal, commit: true)
        return APIReminderList(
            id: cal.calendarIdentifier,
            name: cal.title,
            isDefault: false
        )
    }

    func fetchReminders(listID: String? = nil) async throws -> [APIReminder] {
        if let lID = listID {
            // If user requests a particular reminder list:
            guard let cal = store.calendar(withIdentifier: lID),
                  isReminderCalendar(cal)
            else {
                throw Abort(.notFound, reason: "Reminder list not found.")
            }
            return try await withCheckedThrowingContinuation { cont in
                let pred = store.predicateForReminders(in: [cal])
                store.fetchReminders(matching: pred) { ekReminders in
                    let safeReminders = (ekReminders ?? []).map { self.toAPIReminder($0) }
                    cont.resume(returning: safeReminders)
                }
            }
        } else {
            // If none specified, fetch from all reminder lists
            return try await fetchRemindersAll()
        }
    }

    private func fetchRemindersAll() async throws -> [APIReminder] {
        try await withCheckedThrowingContinuation { cont in
            let pred = store.predicateForReminders(in: nil)
            store.fetchReminders(matching: pred) { ekReminders in
                let safeReminders = (ekReminders ?? []).map { self.toAPIReminder($0) }
                cont.resume(returning: safeReminders)
            }
        }
    }

    func createReminder(_ data: APIReminder) async throws -> APIReminder {
        guard let cal = store.calendar(withIdentifier: data.listID),
              isReminderCalendar(cal)
        else {
            throw Abort(.notFound, reason: "Reminder list not found.")
        }

        let rem = EKReminder(eventStore: store)
        rem.calendar = cal
        rem.title = data.title
        rem.notes = data.notes
        if let dueDate = data.dueDate {
            let comps = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second],
                                                        from: dueDate)
            rem.dueDateComponents = comps
        }
        rem.isCompleted = data.completed

        try store.save(rem, commit: true)
        return toAPIReminder(rem)
    }

    func updateReminder(id: String, with data: APIReminder) async throws -> APIReminder {
        let oldEK = try await fetchEKReminderByID(id)
        oldEK.title = data.title
        oldEK.notes = data.notes
        if let dueDate = data.dueDate {
            let comps = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second],
                                                        from: dueDate)
            oldEK.dueDateComponents = comps
        }
        oldEK.isCompleted = data.completed

        // If the user moves the reminder to a different list
        if oldEK.calendar.calendarIdentifier != data.listID {
            guard let newCal = store.calendar(withIdentifier: data.listID),
                  isReminderCalendar(newCal)
            else {
                throw Abort(.notFound, reason: "New reminder list not found.")
            }
            oldEK.calendar = newCal
        }

        try store.save(oldEK, commit: true)
        return toAPIReminder(oldEK)
    }

    func deleteReminder(id: String) async throws {
        let allRems = try await fetchRemindersAll()
        guard let remID = allRems.first(where: { $0.id == id }) else {
            throw Abort(.notFound, reason: "Reminder not found.")
        }
        let actual = try await fetchEKReminderByID(remID.id)
        try store.remove(actual, commit: true)
    }

    private func fetchEKReminderByID(_ id: String) async throws -> EKReminder {
        let ekReminders = try await withCheckedThrowingContinuation { cont in
            let pred = store.predicateForReminders(in: nil)
            store.fetchReminders(matching: pred) { rawRems in
                cont.resume(returning: rawRems ?? [])
            }
        }
        guard let found = ekReminders.first(where: { $0.calendarItemIdentifier == id }) else {
            throw Abort(.notFound, reason: "Reminder not found.")
        }
        return found
    }

    /// Convert a single EKReminder -> APIReminder, including the `listName`.
    private func toAPIReminder(_ r: EKReminder) -> APIReminder {
        APIReminder(
            id: r.calendarItemIdentifier,
            title: r.title,
            dueDate: r.dueDateComponents?.date,
            completed: r.isCompleted,
            notes: r.notes,
            linkedEventID: nil,
            listID: r.calendar.calendarIdentifier,
            listName: r.calendar.title   // <-- Include the calendar's title
        )
    }

    // --------------------------------------------------
    // MARK: - Availability Handling
    // --------------------------------------------------

    /// Convert an `EKEventAvailability` enum into a string for `APIEvent.availability`.
    private func availabilityString(for avail: EKEventAvailability) -> String {
        switch avail {
        case .notSupported: return "notSupported"
        case .busy:         return "busy"
        case .free:         return "free"
        case .tentative:    return "tentative"
        case .unavailable:  return "unavailable"
        @unknown default:   return "unknown"
        }
    }

    /// Parse a string (like "busy", "free", "tentative") into an EKEventAvailability enum.
    private func parseAvailability(_ availabilityString: String?) -> EKEventAvailability {
        switch availabilityString?.lowercased() {
        case "busy":        return .busy
        case "free":        return .free
        case "tentative":   return .tentative
        case "unavailable": return .unavailable
        default:            return .notSupported
        }
    }
}
