import Vapor
import Foundation

final class UserInfoService {
    private let logger: Logger
    private let configService: UserConfigService
    private let aboutPath: String
    private let eventKitActor: EventKitActor

    init(app: Application, configService: UserConfigService, eventKitActor: EventKitActor) {
        self.logger = app.logger
        self.configService = configService
        self.eventKitActor = eventKitActor

        // If you store your 'about' file at Public/api/exoself/about/index.md:
        self.aboutPath = app.directory.publicDirectory + "api/exoself/about/index.md"
    }

    // Existing config-based methods
    func primaryCalendars() -> [String] {
        configService.userConfig.primaryCalendars
    }

    func primaryTimezone() -> String {
        configService.userConfig.primaryTimezone
    }

    func aboutMarkdown() -> String {
        do {
            let data = try Data(contentsOf: URL(fileURLWithPath: aboutPath))
            return String(decoding: data, as: UTF8.self)
        } catch {
            logger.report(error: error)
            return "# About the User\n\n*(Error reading bio...)*"
        }
    }

    /// Convert the user’s config-based calendar *names* into actual IDs.
    /// If multiple calendars share the same name, we keep the first ID and log a warning for duplicates.
    ///
    /// For example, if user-config.json has ["Work", "Personal"], we:
    ///  1) fetch all APICalendars from eventKitActor
    ///  2) build a map name->id, ignoring subsequent duplicates for the same name
    ///  3) for each name in userConfig, look up the ID in that map
    ///  4) skip or warn if name not found
    ///
    func primaryCalendarIDs() async throws -> [String] {
        // e.g. ["Work", "Personal", "Birthdays"]
        let names = configService.userConfig.primaryCalendars

        // fetch all event calendars from the actor
        let allCals = try await eventKitActor.fetchCalendars() // [APICalendar]

        // build name->id dictionary, skipping duplicates
        var nameToID = [String: String]()  // key: name, value: id
        for cal in allCals {
            if let existingID = nameToID[cal.name] {
                // We already have an ID for that name => log a warning
                // but keep the first
                logger.warning("Found duplicate calendar name '\(cal.name)'. Skipping ID \(cal.id). Using existing ID \(existingID).")
            } else {
                nameToID[cal.name] = cal.id
            }
        }

        // now map each name from user config to the actual ID
        var results = [String]()
        for nm in names {
            if let cid = nameToID[nm] {
                results.append(cid)
            } else {
                logger.warning("Primary calendar name '\(nm)' was not found among known calendars.")
            }
        }
        return results
    }
}
