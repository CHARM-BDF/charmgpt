import Vapor
import Foundation

/// The decoded form of user-config.json
struct UserConfig: Codable {
    let primaryCalendars: [String]
    let primaryTimezone: String
}

/// Service to load user-config.json at app startup
final class UserConfigService {
    private let logger: Logger
    private(set) var userConfig: UserConfig

    init(app: Application) throws {
        self.logger = app.logger
        let configPath = app.directory.workingDirectory + "Config/user-config.json"
        self.logger.info("Loading user config from \(configPath)")

        let data = try Data(contentsOf: URL(fileURLWithPath: configPath))
        self.userConfig = try JSONDecoder().decode(UserConfig.self, from: data)
    }
}
