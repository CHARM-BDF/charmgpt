//
//  UserController.swift
//
//  A new controller that organizes all user-related endpoints under /user.
//  - GET /user => returns combined JSON with about, timezone, and primary calendars
//  - GET /user/about => returns about in Markdown
//  - GET /user/timezone => returns timezone in JSON
//  - GET /user/primary-calendars => returns array of calendar IDs
//

import Vapor

struct UserController: RouteCollection {
    let userInfoService: UserInfoService

    func boot(routes: RoutesBuilder) throws {
        // 1) GET /user => combined user info
        routes.get(use: getAllUserInfo)

        // 2) GET /user/about => just the about content (Markdown)
        routes.get("about", use: getAboutMarkdown)

        // 3) GET /user/timezone => just the user’s time zone
        routes.get("timezone", use: getUserTimezone)

        // 4) GET /user/primary-calendars => array of primary calendar IDs
        routes.get("primary-calendars", use: getPrimaryCalendars)
    }

    // ------------------------------------------------------------
    // MARK: - 1) GET /user
    // ------------------------------------------------------------
    /// This returns a single JSON payload containing:
    ///  - aboutMarkdown: string (from about.md)
    ///  - timezone: string
    ///  - primaryCalendars: [string]
    ///
    func getAllUserInfo(_ req: Request) async throws -> UserBundle {
        // 1) Markdown
        let about = userInfoService.aboutMarkdown()
        // 2) Timezone
        let tz = userInfoService.primaryTimezone()
        // 3) Primary calendars
        let cals = userInfoService.primaryCalendars()

        return UserBundle(
            aboutMarkdown: about,
            timezone: tz,
            primaryCalendars: cals
        )
    }

    // ------------------------------------------------------------
    // MARK: - 2) GET /user/about
    // ------------------------------------------------------------
    /// Returns the user’s "about" content as text/markdown. 
    /// If a client specifically needs the standalone markdown.
    func getAboutMarkdown(_ req: Request) async throws -> Response {
        let bioText = userInfoService.aboutMarkdown()
        let headers: HTTPHeaders = ["Content-Type": "text/markdown; charset=utf-8"]
        return Response(status: .ok, headers: headers, body: .init(string: bioText))
    }

    // ------------------------------------------------------------
    // MARK: - 3) GET /user/timezone
    // ------------------------------------------------------------
    /// Returns JSON with { "timezone": "America/Chicago" }, for instance.
    func getUserTimezone(_ req: Request) async throws -> [String: String] {
        let tz = userInfoService.primaryTimezone()
        return ["timezone": tz]
    }

    // ------------------------------------------------------------
    // MARK: - 4) GET /user/primary-calendars
    // ------------------------------------------------------------
    /// Returns the user’s primary calendar IDs as JSON array.
    func getPrimaryCalendars(_ req: Request) async throws -> [String] {
        userInfoService.primaryCalendars()
    }
}

// MARK: - Supporting Data Structures

/// A single JSON object returning *all* user info at once.
struct UserBundle: Content {
    let aboutMarkdown: String
    let timezone: String
    let primaryCalendars: [String]
}