import Vapor

struct APIKeyAuthMiddleware: AsyncMiddleware {
    /// The expected token to match against.
    let validToken: String
    
    func respond(to request: Request, chainingTo next: AsyncResponder) async throws -> Response {
        // If you want some routes *without* auth, you can check if current path
        // requires auth or not. For brevity, we'll secure *all* routes.
        
        guard let authHeader = request.headers["Authorization"].first else {
            throw Abort(.unauthorized, reason: "Missing Authorization header")
        }
        
        // Examples:
        // "Authorization: Bearer YOUR_API_KEY"
        // "Authorization: Basic YOUR_API_KEY"
        
        if authHeader.hasPrefix("Bearer ") {
            // e.g. "Bearer abc123"
            let tokenValue = String(authHeader.dropFirst("Bearer ".count))
            if tokenValue != validToken {
                throw Abort(.unauthorized, reason: "Invalid Bearer token.")
            }
        } else if authHeader.hasPrefix("Basic ") {
            // e.g. "Basic abc123"
            let tokenValue = String(authHeader.dropFirst("Basic ".count))
            if tokenValue != validToken {
                throw Abort(.unauthorized, reason: "Invalid Basic token.")
            }
        } else {
            throw Abort(.unauthorized, reason: "Unsupported Authorization scheme.")
        }
        
        return try await next.respond(to: request)
    }
}
