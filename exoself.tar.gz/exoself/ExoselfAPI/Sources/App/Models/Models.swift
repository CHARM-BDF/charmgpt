// Sources/App/Models.swift

import Vapor

/// Represents a calendar in our API.
struct APICalendar: Content {
    let id: String
    let name: String
    let isDefault: Bool
}

/// Represents an event in our API.
struct APIEvent: Content {
    let id: String?
    let calendarID: String
    let calendarName: String   // <-- Added field
    let title: String
    let startTime: Date
    let endTime: Date
    let allDay: Bool
    let location: String?
    var notes: String?
    let recurrenceRule: String?
    let availability: String?
}

/// Represents a reminder list in our API.
struct APIReminderList: Content {
    let id: String
    let name: String
    let isDefault: Bool
}

/// Represents a reminder in our API.
struct APIReminder: Content {
    let id: String
    let title: String
    let dueDate: Date?
    let completed: Bool
    let notes: String?
    let linkedEventID: String?
    let listID: String
    let listName: String       // <-- Added field
}

