#!/bin/bash

# TODO: Make this EXOSELF_

export BASE_URL="api/exoself"
export API_KEY="supersecret"
export PORT=5001

swift run

