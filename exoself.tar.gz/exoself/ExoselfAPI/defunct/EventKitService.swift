import Foundation
import EventKit
import Vapor

final class EventKitService {
    private let store = EKEventStore()
    
    init() {
        // Request access to both event and reminder data at init.
        store.requestAccess(to: .event) { granted, error in
            if let error = error {
                print("Error requesting calendar access: \(error)")
            }
            if !granted {
                print("Calendar access not granted")
            }
        }
        store.requestAccess(to: .reminder) { granted, error in
            if let error = error {
                print("Error requesting reminder access: \(error)")
            }
            if !granted {
                print("Reminder access not granted")
            }
        }
    }
    
    // MARK: - Calendars
    func fetchCalendars() -> [EKCalendar] {
        store.calendars(for: .event)
    }
    
    func createCalendar(named name: String) throws -> EKCalendar {
        let calendar = EKCalendar(for: .event, eventStore: store)
        calendar.title = name
        // You need to assign a valid EKSource (e.g., iCloud or On My Mac)
        // For simplicity, pick the first local source if available:
        guard let localSource = store.sources.first(where: { $0.sourceType == .local }) else {
            throw Abort(.internalServerError, reason: "No local source found.")
        }
        calendar.source = localSource
        
        try store.saveCalendar(calendar, commit: true)
        return calendar
    }
    
    func deleteCalendar(id: String) throws {
        guard let calendar = store.calendar(withIdentifier: id) else {
            throw Abort(.notFound, reason: "Calendar not found.")
        }
        try store.removeCalendar(calendar, commit: true)
    }
    
    // MARK: - Events
    func fetchEvents(start: Date?, end: Date?, calendarID: String?) -> [EKEvent] {
        let calendars: [EKCalendar]
        if let calID = calendarID, let specificCalendar = store.calendar(withIdentifier: calID) {
            calendars = [specificCalendar]
        } else {
            calendars = store.calendars(for: .event)
        }
        
        // Default to one week range if not specified
        let startDate = start ?? Date().addingTimeInterval(-7 * 24 * 3600)
        let endDate = end ?? Date().addingTimeInterval(7 * 24 * 3600)
        
        let predicate = store.predicateForEvents(withStart: startDate, end: endDate, calendars: calendars)
        let events = store.events(matching: predicate)
        return events
    }
    
    func createEvent(_ eventData: APIEvent) throws -> EKEvent {
        let ekEvent = EKEvent(eventStore: store)
        ekEvent.calendar = store.calendar(withIdentifier: eventData.calendarID)
        ekEvent.title = eventData.title
        ekEvent.startDate = eventData.startTime
        ekEvent.endDate = eventData.endTime
        ekEvent.isAllDay = eventData.allDay
        ekEvent.location = eventData.location
        ekEvent.notes = eventData.notes
        
        // Recurrence rule is optional; parse if provided
        if let ruleString = eventData.recurrenceRule {
            // You’d parse the rule (e.g., “FREQ=WEEKLY;BYDAY=MO,WE”) into EKRecurrenceRule here.
            // This example leaves it as an exercise.
        }
        
        try store.save(ekEvent, span: .thisEvent, commit: true)
        return ekEvent
    }
    
    func updateEvent(id: String, with data: APIEvent) throws -> EKEvent {
        guard let ekEvent = store.event(withIdentifier: id) else {
            throw Abort(.notFound, reason: "Event not found.")
        }
        ekEvent.title = data.title
        ekEvent.startDate = data.startTime
        ekEvent.endDate = data.endTime
        ekEvent.isAllDay = data.allDay
        ekEvent.location = data.location
        ekEvent.notes = data.notes
        // Also handle recurrence rule updates if needed
        
        try store.save(ekEvent, span: .thisEvent, commit: true)
        return ekEvent
    }
    
    func deleteEvent(id: String) throws {
        guard let ekEvent = store.event(withIdentifier: id) else {
            throw Abort(.notFound, reason: "Event not found.")
        }
        try store.remove(ekEvent, span: .thisEvent, commit: true)
    }
    
    // MARK: - Reminders
    func fetchReminders() async throws -> [EKReminder] {
        return try await withCheckedThrowingContinuation { continuation in
            let predicate = store.predicateForReminders(in: nil)
            store.fetchReminders(matching: predicate) { reminders in
                if let reminders = reminders {
                    continuation.resume(returning: reminders)
                } else {
                    continuation.resume(returning: [])
                }
            }
        }
    }
    
    func createReminder(_ reminderData: APIReminder) throws -> EKReminder {
        let reminder = EKReminder(eventStore: store)
        reminder.title = reminderData.title
        reminder.notes = reminderData.notes
        if let dueDate = reminderData.dueDate {
            let dateComponents = Calendar.current.dateComponents(
                [.year, .month, .day, .hour, .minute, .second],
                from: dueDate
            )
            reminder.dueDateComponents = dateComponents
        }
        reminder.isCompleted = reminderData.completed
        
        // You need to pick a default reminders calendar or a user-specified one
        // For example, pick the first reminders calendar in the store:
        guard let defaultRemindersCalendar = store.defaultCalendarForNewReminders() else {
            throw Abort(.internalServerError, reason: "No default reminders calendar found.")
        }
        reminder.calendar = defaultRemindersCalendar
        
        try store.save(reminder, commit: true)
        return reminder
    }
    
    func updateReminder(id: String, with data: APIReminder) async throws -> EKReminder {
        // There’s no direct method to fetch a single EKReminder by ID.
        // You have to fetch all reminders and filter or store references in a DB.
        // For demonstration, we’ll fetch all and find the matching one:
        let allReminders = try await fetchReminders()
        
        guard let reminder = allReminders.first(where: { $0.calendarItemIdentifier == id }) else {
            throw Abort(.notFound, reason: "Reminder not found.")
        }
        
        reminder.title = data.title
        reminder.notes = data.notes
        if let dueDate = data.dueDate {
            let dateComponents = Calendar.current.dateComponents(
                [.year, .month, .day, .hour, .minute, .second],
                from: dueDate
            )
            reminder.dueDateComponents = dateComponents
        }
        reminder.isCompleted = data.completed
        
        try store.save(reminder, commit: true)
        return reminder
    }
    
    func deleteReminder(id: String) async throws {
        let allReminders = try await fetchReminders()
        
        guard let reminder = allReminders.first(where: { $0.calendarItemIdentifier == id }) else {
            throw Abort(.notFound, reason: "Reminder not found.")
        }
        
        try store.remove(reminder, commit: true)
    }
}

