#!/usr/bin/env bash
#
# Tests the Reminders and basic user info endpoints more thoroughly.
# Usage:
#   ./test_reminders_userinfo.sh [HOST] [PORT] [API_KEY]
# Defaults:
#   HOST=localhost
#   PORT=5001
#   API_KEY=supersecret

HOST=${1:-localhost}
PORT=${2:-5001}
API_KEY=${3:-supersecret}
BASE_URL="http://$HOST:$PORT/api/exoself"

echo "=== TEST REMINDERS & USER INFO ==="
echo "Using BASE_URL=$BASE_URL"
echo "Using API_KEY=$API_KEY"
echo

# 1) Create a new reminder list
echo "1) Creating new reminder list..."
RL_JSON=$(curl -s -X POST \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"name":"TestRemindersList"}' \
  "$BASE_URL/reminder-lists")
RL_ID=$(echo "$RL_JSON" | jq -r '.id')
echo "   Created => $RL_JSON"

# 2) Create a new reminder
echo
echo "2) Creating a reminder in that list..."
REM1_JSON=$(curl -s -X POST \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d "{
    \"title\": \"Test Reminder #1\",
    \"dueDate\": \"2025-03-01T15:00:00Z\",
    \"completed\": false,
    \"notes\": \"Check for groceries\",
    \"listID\": \"$RL_ID\"
  }" \
  "$BASE_URL/reminders")
REM1_ID=$(echo "$REM1_JSON" | jq -r '.id')
echo "   Created => $REM1_JSON"

# 3) Update the reminder
echo
echo "3) Updating the reminder to completed..."
UPD_REM1_JSON=$(curl -s -X PUT \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d "{
    \"id\": \"$REM1_ID\",
    \"title\": \"Test Reminder #1 Updated\",
    \"dueDate\": \"2025-03-01T15:00:00Z\",
    \"completed\": true,
    \"notes\": \"Done!\",
    \"listID\": \"$RL_ID\"
  }" \
  "$BASE_URL/reminders/$REM1_ID")
echo "   Updated => $UPD_REM1_JSON"

# 4) GET /reminders (filter by completed=true)
echo
echo "4) GET /reminders with completed=true..."
FILT_REM=$(curl -s \
  -H "Authorization: Bearer $API_KEY" \
  "$BASE_URL/reminders?completed=true")
echo "   Filtered reminders => $FILT_REM"

# 5) Delete the reminder
echo
echo "5) Deleting reminder..."
curl -s -X DELETE \
  -H "Authorization: Bearer $API_KEY" \
  "$BASE_URL/reminders/$REM1_ID"

# 6) Delete the list
echo
echo "6) Deleting reminder list..."
curl -s -X DELETE \
  -H "Authorization: Bearer $API_KEY" \
  "$BASE_URL/reminder-lists/$RL_ID" >/dev/null

echo
echo "Check /about or /primary-calendars as well if needed..."
ABOUT_DATA=$(curl -s -H "Authorization: Bearer $API_KEY" "$BASE_URL/about")
echo "   /about =>"
echo "$ABOUT_DATA"

PCALS_DATA=$(curl -s -H "Authorization: Bearer $API_KEY" "$BASE_URL/primary-calendars")
echo
echo "   /primary-calendars => $PCALS_DATA"

echo
echo "All done!"
exit 0
