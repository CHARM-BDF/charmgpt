#!/usr/bin/env bash
#
# test_calendar.sh
#
# Tests the Calendar APIs of the ExoselfAPI.
# Usage:
#   ./test_calendar.sh [hostname] [port] [apikey]
# Defaults:
#   hostname=localhost
#   port=5001
#   apikey=supersecret
#
# Requirements:
#   - curl
#   - jq (for parsing JSON)
#

# ---------------------------------------
# 1) Parse arguments & set defaults
# ---------------------------------------
HOST=${1:-localhost}
PORT=${2:-5001}
API_KEY=${3:-supersecret}

# Construct base URL
BASE_URL="http://$HOST:$PORT/api/exoself"

echo "Using BASE_URL=$BASE_URL"
echo "Using API_KEY=$API_KEY"
echo

# ---------------------------------------
# Helper function for pretty-printing
# ---------------------------------------
function echo_section() {
  echo
  echo "====================  $1  ===================="
}

# ---------------------------------------
# 2) Create Test Calendars
# ---------------------------------------
echo_section "CREATE TEST CALENDARS"

CAL1_JSON=$(curl -s -X POST \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  "$BASE_URL/calendars" \
  -d '{"name":"TestCalendar1"}')

CAL2_JSON=$(curl -s -X POST \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  "$BASE_URL/calendars" \
  -d '{"name":"TestCalendar2"}')

echo "Create Calendar1: $CAL1_JSON"
echo "Create Calendar2: $CAL2_JSON"

CAL1_ID=$(echo "$CAL1_JSON" | jq -r '.id')
CAL2_ID=$(echo "$CAL2_JSON" | jq -r '.id')

if [[ "$CAL1_ID" == "null" || "$CAL2_ID" == "null" ]]; then
  echo "ERROR creating calendars. Exiting."
  exit 1
fi

echo "TestCalendar1 ID = $CAL1_ID"
echo "TestCalendar2 ID = $CAL2_ID"

# ---------------------------------------
# 3) Populate with some events
# ---------------------------------------
echo_section "CREATE EVENTS IN EACH CALENDAR"

# Sample times: now + 1 hour, now + 2 hours
NOW_UTC=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
START_UTC=$(date -u -v+1H +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date -u -d "+1 hour" +"%Y-%m-%dT%H:%M:%SZ")
END_UTC=$(date -u -v+2H +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date -u -d "+2 hours" +"%Y-%m-%dT%H:%M:%SZ")

EVENT1_JSON=$(curl -s -X POST \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  "$BASE_URL/events" \
  -d "{
    \"id\": \"\",
    \"calendarID\": \"$CAL1_ID\",
    \"title\": \"My Test Event #1\",
    \"startTime\": \"$START_UTC\",
    \"endTime\": \"$END_UTC\",
    \"allDay\": false,
    \"location\": \"Office\",
    \"notes\": \"Testing event creation\",
    \"recurrenceRule\": null,
    \"availability\": \"busy\"
  }")

EVENT2_JSON=$(curl -s -X POST \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  "$BASE_URL/events" \
  -d "{
    \"id\": \"\",
    \"calendarID\": \"$CAL2_ID\",
    \"title\": \"My Test Event #2\",
    \"startTime\": \"$START_UTC\",
    \"endTime\": \"$END_UTC\",
    \"allDay\": false,
    \"location\": \"Boardroom\",
    \"notes\": \"Testing event creation in second calendar\",
    \"recurrenceRule\": null,
    \"availability\": \"free\"
  }")

echo "Event #1 creation result: $EVENT1_JSON"
echo "Event #2 creation result: $EVENT2_JSON"

EVENT1_ID=$(echo "$EVENT1_JSON" | jq -r '.id')
EVENT2_ID=$(echo "$EVENT2_JSON" | jq -r '.id')

# ---------------------------------------
# 4) Manipulate events
# ---------------------------------------
echo_section "UPDATE EVENT #1 (change notes, availability)"

UPDATE1_JSON=$(curl -s -X PUT \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  "$BASE_URL/events/$EVENT1_ID" \
  -d "{
    \"id\": \"$EVENT1_ID\",
    \"calendarID\": \"$CAL1_ID\",
    \"title\": \"My Test Event #1 (UPDATED)\",
    \"startTime\": \"$START_UTC\",
    \"endTime\": \"$END_UTC\",
    \"allDay\": false,
    \"location\": \"Updated Office\",
    \"notes\": \"Updated notes.\",
    \"recurrenceRule\": null,
    \"availability\": \"tentative\"
  }")

echo "Update #1 result: $UPDATE1_JSON"

# ---------------------------------------
# 5) Test availability queries
# ---------------------------------------
echo_section "QUERY AVAILABILITY ACROSS BOTH CALENDARS"

# We'll check for availability from now to now+4 hours
AVAIL_START=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
AVAIL_END=$(date -u -v+4H +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date -u -d "+4 hours" +"%Y-%m-%dT%H:%M:%SZ")

AVAILABILITY_JSON=$(curl -s -X GET \
  -H "Authorization: Bearer $API_KEY" \
  "$BASE_URL/availability?calendar_ids=$CAL1_ID,$CAL2_ID&start=$AVAIL_START&end=$AVAIL_END")

echo "Availability (4-hr window) = $AVAILABILITY_JSON"

# Corner case #1: zero-length window
ZERO_AVAIL=$(curl -s -X GET \
  -H "Authorization: Bearer $API_KEY" \
  "$BASE_URL/availability?calendar_ids=$CAL1_ID,$CAL2_ID&start=$AVAIL_START&end=$AVAIL_START")
echo
echo "Corner Case #1 (zero-length window): $ZERO_AVAIL"

# Corner case #2: single calendar only
CAL1_AVAIL=$(curl -s -X GET \
  -H "Authorization: Bearer $API_KEY" \
  "$BASE_URL/availability?calendar_ids=$CAL1_ID&start=$AVAIL_START&end=$AVAIL_END")
echo
echo "Corner Case #2 (single calendar availability): $CAL1_AVAIL"

# ---------------------------------------
# 6) Clean up (optional)
# ---------------------------------------
echo_section "DELETE EVENTS AND CALENDARS (CLEAN UP)"

if [ -n "$EVENT1_ID" ] && [ "$EVENT1_ID" != "null" ]; then
  DEL_EV1=$(curl -s -X DELETE \
    -H "Authorization: Bearer $API_KEY" \
    "$BASE_URL/events/$EVENT1_ID")
  echo "Delete Event #1 => HTTP $?"
fi

if [ -n "$EVENT2_ID" ] && [ "$EVENT2_ID" != "null" ]; then
  DEL_EV2=$(curl -s -X DELETE \
    -H "Authorization: Bearer $API_KEY" \
    "$BASE_URL/events/$EVENT2_ID")
  echo "Delete Event #2 => HTTP $?"
fi

if [ -n "$CAL1_ID" ] && [ "$CAL1_ID" != "null" ]; then
  DEL_CAL1=$(curl -s -X DELETE \
    -H "Authorization: Bearer $API_KEY" \
    "$BASE_URL/calendars/$CAL1_ID")
  echo "Delete Calendar1 => HTTP $?"
fi

if [ -n "$CAL2_ID" ] && [ "$CAL2_ID" != "null" ]; then
  DEL_CAL2=$(curl -s -X DELETE \
    -H "Authorization: Bearer $API_KEY" \
    "$BASE_URL/calendars/$CAL2_ID")
  echo "Delete Calendar2 => HTTP $?"
fi

echo
echo "==================== TESTS COMPLETE ===================="
exit 0
