#!/usr/bin/env bash
#
# test_calendar_events.sh
#
# Expanded tests for Calendars, Events, and Availability.
#   - Create two calendars.
#   - Create multiple events, including an all-day event, partial overlaps, etc.
#   - Verify results with `jq`, checking for "allDay" = true, etc.
#   - Check availability to ensure these events block properly.
#
# Usage:
#   ./test_calendar_events.sh [HOST] [PORT] [API_KEY]
# Defaults:
#   HOST=localhost
#   PORT=5001
#   API_KEY=supersecret
#
# Requirements:
#   - curl
#   - jq
#

HOST=${1:-localhost}
PORT=${2:-5001}
API_KEY=${3:-supersecret}
BASE_URL="http://$HOST:$PORT/api/exoself"

echo "=== TEST CALENDAR & EVENTS (Including All-Day/Overlapping) ==="
echo "Using BASE_URL=$BASE_URL"
echo "Using API_KEY=$API_KEY"
echo

# Helper function to pretty-print a fail message and exit
function fail() {
  echo "TEST FAILED: $1"
  exit 1
}

# 1) Check /about
echo "1) Testing /about endpoint..."
ABOUT_RES=$(curl -s -X GET \
  -H "Authorization: Bearer $API_KEY" \
  "$BASE_URL/about")
if [[ "$ABOUT_RES" == *"Error reading bio"* ]]; then
  echo "   WARNING: 'Error reading bio...' found. Perhaps index.md not found or unreadable."
fi
echo "   Response from /about:"
echo "----------------------"
echo "$ABOUT_RES"
echo "----------------------"

# 2) Check /primary-calendars
echo "2) Testing /primary-calendars endpoint..."
PCALS_RES=$(curl -s -X GET \
  -H "Authorization: Bearer $API_KEY" \
  "$BASE_URL/primary-calendars")
echo "   Response from /primary-calendars: $PCALS_RES"

# 3) Create two calendars
CAL_A_NAME="TestCalendarA"
CAL_B_NAME="TestCalendarB"

echo
echo "3) Create calendars '$CAL_A_NAME' and '$CAL_B_NAME'"

CAL_A_JSON=$(curl -s -X POST \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d "{\"name\": \"$CAL_A_NAME\"}" \
  "$BASE_URL/calendars")
CAL_A_ID=$(echo "$CAL_A_JSON" | jq -r '.id')
echo "   Created => $CAL_A_JSON"
if [[ "$CAL_A_ID" == "null" ]]; then
  fail "Failed to create $CAL_A_NAME"
fi

CAL_B_JSON=$(curl -s -X POST \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d "{\"name\": \"$CAL_B_NAME\"}" \
  "$BASE_URL/calendars")
CAL_B_ID=$(echo "$CAL_B_JSON" | jq -r '.id')
echo "   Created => $CAL_B_JSON"
if [[ "$CAL_B_ID" == "null" ]]; then
  fail "Failed to create $CAL_B_NAME"
fi

# 4) Create multiple events
#    We'll do:
#     - A partial overlap event in Calendar A.
#     - An all-day event in Calendar B.
#     - Another event in B that partially overlaps.

# Start/End for partial day
NOW=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
START_1=$(date -u -v+1H +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date -u -d "+1 hour" +"%Y-%m-%dT%H:%M:%SZ")
END_1=$(date -u -v+2H +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date -u -d "+2 hours" +"%Y-%m-%dT%H:%M:%SZ")

# For all-day, pick tomorrow
TOMORROW=$(date -u -v+1d +"%Y-%m-%dT00:00:00Z" 2>/dev/null || date -u -d "+1 day" +"%Y-%m-%dT00:00:00Z")
NEXTDAY=$(date -u -v+2d +"%Y-%m-%dT00:00:00Z" 2>/dev/null || date -u -d "+2 days" +"%Y-%m-%dT00:00:00Z")

echo
echo "4) Create partial overlap event in Calendar A..."
EV_A_JSON=$(curl -s -X POST \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d "{
    \"calendarID\": \"$CAL_A_ID\",
    \"title\": \"PartialOverlapEventA\",
    \"startTime\": \"$START_1\",
    \"endTime\": \"$END_1\",
    \"allDay\": false,
    \"availability\": \"busy\"
  }" \
  "$BASE_URL/events")
echo "   Created event in A => $EV_A_JSON"
EV_A_ID=$(echo "$EV_A_JSON" | jq -r '.id')
IS_ALLDAY_A=$(echo "$EV_A_JSON" | jq -r '.allDay')
if [[ "$IS_ALLDAY_A" != "false" ]]; then
  fail "Expected event in A to have allDay=false, got $IS_ALLDAY_A"
fi

# All-day event in Calendar B (tomorrow -> tomorrow+1day)
echo
echo "5) Create all-day event in Calendar B..."
EV_B_JSON=$(curl -s -X POST \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d "{
    \"calendarID\": \"$CAL_B_ID\",
    \"title\": \"AllDayEventB\",
    \"startTime\": \"$TOMORROW\",
    \"endTime\": \"$NEXTDAY\",
    \"allDay\": true,
    \"availability\": \"busy\"
  }" \
  "$BASE_URL/events")
echo "   Created event in B => $EV_B_JSON"
EV_B_ID=$(echo "$EV_B_JSON" | jq -r '.id')
IS_ALLDAY_B=$(echo "$EV_B_JSON" | jq -r '.allDay')
if [[ "$IS_ALLDAY_B" != "true" ]]; then
  fail "Expected allDay=true for event in B, got $IS_ALLDAY_B"
fi

# Another partial overlap in B, same day as partial overlap in A
# We'll pick the same times as A for overlap demonstration
echo
echo "6) Create partial overlap event in Calendar B (same times as event in A)..."
EV_B2_JSON=$(curl -s -X POST \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d "{
    \"calendarID\": \"$CAL_B_ID\",
    \"title\": \"OverlapEventB2\",
    \"startTime\": \"$START_1\",
    \"endTime\": \"$END_1\",
    \"allDay\": false,
    \"availability\": \"busy\"
  }" \
  "$BASE_URL/events")
echo "   Created event => $EV_B2_JSON"
EV_B2_ID=$(echo "$EV_B2_JSON" | jq -r '.id')

# 7) Confirm the /events endpoint sees them with correct allDay settings
echo
echo "7) Checking /events for each newly created event..."

GET_EV_A=$(curl -s -H "Authorization: Bearer $API_KEY" "$BASE_URL/events/$EV_A_ID")
GET_EV_B=$(curl -s -H "Authorization: Bearer $API_KEY" "$BASE_URL/events/$EV_B_ID")
GET_EV_B2=$(curl -s -H "Authorization: Bearer $API_KEY" "$BASE_URL/events/$EV_B2_ID")

echo "   /events/$EV_A_ID => $GET_EV_A"
echo "   /events/$EV_B_ID => $GET_EV_B"
echo "   /events/$EV_B2_ID => $GET_EV_B2"

# 8) Check availability:
echo
echo "8) Checking availability around partial day events (A+B)..."
# We'll check from NOW to NOW+4h
AVAIL_PARTIAL=$(curl -s -X GET \
  -H "Authorization: Bearer $API_KEY" \
  "$BASE_URL/availability?calendar_ids=$CAL_A_ID,$CAL_B_ID&start=$NOW&end=$(date -u -v+4H +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date -u -d "+4 hour" +"%Y-%m-%dT%H:%M:%SZ")")
echo "   A+B partial overlap availability => $AVAIL_PARTIAL"

# 9) Check availability across the all-day event
echo
echo "9) Checking availability for the day of the all-day event..."
# We'll check from T0=(tomorrow 00:00Z) to T1=(tomorrow + 24h)
AVAIL_ALLDAY=$(curl -s -X GET \
  -H "Authorization: Bearer $API_KEY" \
  "$BASE_URL/availability?calendar_ids=$CAL_B_ID&start=$TOMORROW&end=$NEXTDAY")
echo "   Availability for B from $TOMORROW to $NEXTDAY => $AVAIL_ALLDAY"
# If all-day is busy, we'd expect to see no free intervals in that day.

# 10) Clean up
echo
echo "10) Clean up events/calendars..."

echo "   Deleting events..."
[ -n "$EV_A_ID" ] && curl -s -X DELETE -H "Authorization: Bearer $API_KEY" "$BASE_URL/events/$EV_A_ID" >/dev/null
[ -n "$EV_B_ID" ] && curl -s -X DELETE -H "Authorization: Bearer $API_KEY" "$BASE_URL/events/$EV_B_ID" >/dev/null
[ -n "$EV_B2_ID" ] && curl -s -X DELETE -H "Authorization: Bearer $API_KEY" "$BASE_URL/events/$EV_B2_ID" >/dev/null

echo "   Deleting calendars..."
[ -n "$CAL_A_ID" ] && curl -s -X DELETE -H "Authorization: Bearer $API_KEY" "$BASE_URL/calendars/$CAL_A_ID" >/dev/null
[ -n "$CAL_B_ID" ] && curl -s -X DELETE -H "Authorization: Bearer $API_KEY" "$BASE_URL/calendars/$CAL_B_ID" >/dev/null

echo
echo "All done!"
exit 0