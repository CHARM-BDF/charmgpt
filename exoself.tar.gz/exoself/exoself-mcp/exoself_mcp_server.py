import asyncio
import os
import sys
import json
import httpx
from urllib.parse import urlencode, quote

import mcp.types as types
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.server.models import InitializationOptions
from mcp.server import NotificationOptions

##############################################################
# ENVIRONMENT CONFIG
##############################################################

# Default base URL = "http://localhost:5001/api/exoself"
EXOSELF_BASE_URL = os.getenv("EXOSELF_BASE_URL", "http://localhost:5001/api/exoself")
EXOSELF_API_KEY  = os.getenv("EXOSELF_API_KEY")

if not EXOSELF_API_KEY:
    raise RuntimeError("Missing EXOSELF_API_KEY environment variable.")

# We'll store user info after we fetch /user prior to server startup
g_user_info = {
    "aboutMarkdown": None,
    "timezone": None,
    "primaryCalendars": []
}

server = Server("exoself-calendars")

##############################################################
# HELPER
##############################################################

def _update_global_user_info(data: dict):
    """Update our global user info from /user response."""
    about = data.get("aboutMarkdown")
    tz = data.get("timezone")
    pcal = data.get("primaryCalendars", [])
    g_user_info["aboutMarkdown"] = about
    g_user_info["timezone"] = tz
    g_user_info["primaryCalendars"] = pcal

async def fetch_user_info_on_startup():
    """Fetch /user once before we start the MCP server (logs to stderr)."""
    print("[MCP] Pre-start: Fetching /user to get user info...", file=sys.stderr, flush=True)
    async with httpx.AsyncClient() as client:
        headers = {"Authorization": f"Bearer {EXOSELF_API_KEY}"}
        url = f"{EXOSELF_BASE_URL}/user"
        try:
            resp = await client.get(url, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            _update_global_user_info(data)
            print(
                f"[MCP] User info loaded. Time zone: {g_user_info['timezone']}",
                file=sys.stderr, flush=True
            )
        except Exception as e:
            print(f"[MCP] Failed to fetch /user: {e}", file=sys.stderr, flush=True)

##############################################################
# RESOURCES
##############################################################

@server.list_resources()
async def list_resources() -> list[types.Resource]:
    """Example resource: 'exoself://calendars' => GET /calendars."""
    return [
        types.Resource(
            uri="exoself://calendars",
            name="List of Calendars (Resource)",
            mimeType="application/json"
        )
    ]

@server.read_resource()
async def read_resource(uri: str) -> str:
    if uri != "exoself://calendars":
        raise ValueError(f"Unknown resource URI: {uri}")

    async with httpx.AsyncClient() as client:
        headers = {"Authorization": f"Bearer {EXOSELF_API_KEY}"}
        resp = await client.get(f"{EXOSELF_BASE_URL}/calendars", headers=headers)
        resp.raise_for_status()
        return resp.text

##############################################################
# TOOLS
##############################################################

@server.list_tools()
async def handle_list_tools() -> list[types.Tool]:
    """
    Tools:
      1) user (GET /user) "Call this first..."
      2) user_timezone (GET /user/timezone). Show current value from g_user_info.
      3) list_calendars
      4) list_reminder_lists
      5) list_events
      6) list_reminders
      7) agenda
      8) availability
    """
    # We'll embed the time zone from g_user_info in user_timezone's description.
    tz = g_user_info["timezone"] or "Unknown"

    return [
        types.Tool(
            name="user",
            description=(
                "Retrieve all user info (GET /user). "
                "Call this first before doing other calendar functions."
            ),
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        types.Tool(
            name="user_timezone",
            description=(
                f"Retrieve user's primary time zone (GET /user/timezone). "
                f"Current value: {tz}"
            ),
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        types.Tool(
            name="list_calendars",
            description="Retrieve the list of event calendars (GET /calendars).",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        types.Tool(
            name="list_reminder_lists",
            description="Retrieve the list of reminder lists (GET /reminder-lists).",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        types.Tool(
            name="list_events",
            description=(
                "Retrieve events (GET /events) with optional advanced filters. "
                "Supports 'notes_length' to truncate notes (default=100, 'all' for no limit)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "calendar_id":    {"type": "string", "description": "Filter by calendar ID"},
                    "title_contains": {"type": "string", "description": "Substring in title"},
                    "notes_contains": {"type": "string", "description": "Substring in notes"},
                    "start_after":    {"type": "string", "description": "ISO8601 minimal start"},
                    "end_before":     {"type": "string", "description": "ISO8601 maximal end"},
                    "within_seconds": {"type": "string", "description": "Events overlapping now + N seconds"},
                    "before_time":    {"type": "string", "description": "Overlap w/ times before this ISO8601"},
                    "after_time":     {"type": "string", "description": "Overlap w/ times after this ISO8601"},
                    "notes_length":   {
                        "type": "string",
                        "description": (
                            "If omitted or invalid => default 100 chars. 'all' => full notes. "
                            "Or specify a positive integer as string."
                        )
                    },
                },
                "required": []
            }
        ),
        types.Tool(
            name="list_reminders",
            description="Retrieve reminders (GET /reminders) with optional advanced filters.",
            inputSchema={
                "type": "object",
                "properties": {
                    "list_id":           {"type": "string", "description": "Filter by reminder list ID"},
                    "completed":         {"type": "string", "description": "true or false"},
                    "title_contains":    {"type": "string", "description": "Substring match in title"},
                    "notes_contains":    {"type": "string", "description": "Substring match in notes"},
                    "due_before_time":   {"type": "string", "description": "Return items due before this time"},
                    "due_after_time":    {"type": "string", "description": "Return items due after this time"},
                    "due_within_seconds":{"type": "string", "description": "Due within N seconds of now"},
                },
                "required": []
            }
        ),
        types.Tool(
            name="agenda",
            description=(
                "Retrieve agenda events (GET /agenda). "
                "Optional ways to specify date range:\n"
                "  - days=<YYYY-MM-DD..YYYY-MM-DD> for an inclusive range of days\n"
                "  - days=<YYYY-MM-DD,YYYY-MM-DD,...> for discrete days\n"
                "If 'days' is omitted, 'start'/'end' (yyyy-MM-dd) are used (default: today..today).\n"
                "Optional: calendar_ids=comma,separated.\n"
                "Also supports 'notes_length' param for truncating notes."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "days":         {"type": "string", "description": "String specifying days or day-range (e.g. '2025-05-01..2025-05-05' or '2025-05-01,2025-05-10')"},
                    "start":        {"type": "string", "description": "Date (yyyy-MM-dd) for start [fallback if no 'days']"},
                    "end":          {"type": "string", "description": "Date (yyyy-MM-dd) for end [fallback if no 'days']"},
                    "calendar_ids": {"type": "string", "description": "Comma-separated list of calendar IDs"},
                    "notes_length": {
                        "type": "string",
                        "description": (
                            "Truncates notes (default=100). 'all' => no limit. "
                            "Or specify a positive integer as string."
                        )
                    },
                },
                "required": []
            }
        ),
        types.Tool(
            name="availability",
            description=(
                "Find free blocks (GET /availability). Returns JSON { ranges, interpretation }. "
                "Use `intersect` (URL-encoded JSON) to limit availability to provided time ranges. "
                "You can optionally specify `min_duration` (minutes) to filter out shorter intervals. "
                "Recommended for finding availability that matches user-supplied windows."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "calendar_ids":       {"type": "string", "description": "Comma-separated event calendar IDs"},
                    "start":              {"type": "string", "description": "ISO8601 start datetime (required)"},
                    "end":                {"type": "string", "description": "ISO8601 end datetime (required)"},
                    "working_hours_only": {"type": "string", "description": "true or false, default=true (7am-6pm local)"},
                    "intersect": {
                        "type": "array",
                        "description": (
                            "List of time ranges to intersect, must be URL-encoded JSON. "
                            "E.g. `[{\"start\":\"2025-01-21T10:00:00-05:00\",\"end\":\"2025-01-21T11:00:00-05:00\"}]`"
                        ),
                        "items": {
                            "type": "object",
                            "properties": {
                                "start": {"type": "string", "description": "ISO8601 start"},
                                "end":   {"type": "string", "description": "ISO8601 end"}
                            },
                            "required": ["start", "end"]
                        }
                    },
                    "min_duration": {
                        "type": "string",
                        "description": (
                            "Minimum block length (in minutes). E.g. '30' means only intervals "
                            ">=30 minutes appear in the response."
                        )
                    }
                },
                "required": ["start", "end"]
            }
        ),
    ]

@server.call_tool()
async def handle_call_tool(
    name: str,
    arguments: dict
) -> list[types.TextContent | types.ImageContent | types.EmbeddedResource]:
    async with httpx.AsyncClient() as client:
        headers = {"Authorization": f"Bearer {EXOSELF_API_KEY}"}

        # 1) user => GET /user
        if name == "user":
            url = f"{EXOSELF_BASE_URL}/user"
            resp = await client.get(url, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            _update_global_user_info(data)  # refresh global if the user calls this explicitly
            return [types.TextContent(type="text", text=resp.text)]

        # 2) user_timezone => GET /user/timezone
        elif name == "user_timezone":
            url = f"{EXOSELF_BASE_URL}/user/timezone"
            resp = await client.get(url, headers=headers)
            resp.raise_for_status()
            tzobj = resp.json()
            # update global if present
            if "timezone" in tzobj:
                g_user_info["timezone"] = tzobj["timezone"]
            return [types.TextContent(type="text", text=resp.text)]

        # 3) list_calendars
        elif name == "list_calendars":
            url = f"{EXOSELF_BASE_URL}/calendars"
            resp = await client.get(url, headers=headers)
            resp.raise_for_status()
            return [types.TextContent(type="text", text=resp.text)]

        # 4) list_reminder_lists
        elif name == "list_reminder_lists":
            url = f"{EXOSELF_BASE_URL}/reminder-lists"
            resp = await client.get(url, headers=headers)
            resp.raise_for_status()
            return [types.TextContent(type="text", text=resp.text)]

        # 5) list_events
        elif name == "list_events":
            qparams = {}
            if "calendar_id"    in arguments: qparams["calendar_id"]    = arguments["calendar_id"]
            if "title_contains" in arguments: qparams["title_contains"] = arguments["title_contains"]
            if "notes_contains" in arguments: qparams["notes_contains"] = arguments["notes_contains"]
            if "start_after"    in arguments: qparams["start_after"]    = arguments["start_after"]
            if "end_before"     in arguments: qparams["end_before"]     = arguments["end_before"]
            if "within_seconds" in arguments: qparams["within_seconds"] = arguments["within_seconds"]
            if "before_time"    in arguments: qparams["before_time"]    = arguments["before_time"]
            if "after_time"     in arguments: qparams["after_time"]     = arguments["after_time"]
            if "notes_length"   in arguments: qparams["notes_length"]   = arguments["notes_length"]

            url = f"{EXOSELF_BASE_URL}/events"
            if qparams:
                url += "?" + urlencode(qparams)

            resp = await client.get(url, headers=headers)
            resp.raise_for_status()
            return [types.TextContent(type="text", text=resp.text)]

        # 6) list_reminders
        elif name == "list_reminders":
            qparams = {}
            if "list_id"            in arguments: qparams["list_id"]            = arguments["list_id"]
            if "completed"          in arguments: qparams["completed"]          = arguments["completed"]
            if "title_contains"     in arguments: qparams["title_contains"]     = arguments["title_contains"]
            if "notes_contains"     in arguments: qparams["notes_contains"]     = arguments["notes_contains"]
            if "due_before_time"    in arguments: qparams["due_before_time"]    = arguments["due_before_time"]
            if "due_after_time"     in arguments: qparams["due_after_time"]     = arguments["due_after_time"]
            if "due_within_seconds" in arguments: qparams["due_within_seconds"] = arguments["due_within_seconds"]

            url = f"{EXOSELF_BASE_URL}/reminders"
            if qparams:
                url += "?" + urlencode(qparams)

            resp = await client.get(url, headers=headers)
            resp.raise_for_status()
            return [types.TextContent(type="text", text=resp.text)]

        # 7) agenda
        elif name == "agenda":
            qparams = {}
            # handle days param
            if "days" in arguments and arguments["days"]:
                qparams["days"] = arguments["days"]
            else:
                if "start" in arguments: qparams["start"] = arguments["start"]
                if "end"   in arguments: qparams["end"]   = arguments["end"]

            # optional
            if "calendar_ids" in arguments:
                qparams["calendar_ids"] = arguments["calendar_ids"]
            if "notes_length" in arguments and arguments["notes_length"]:
                qparams["notes_length"] = arguments["notes_length"]

            url = f"{EXOSELF_BASE_URL}/agenda"
            if qparams:
                url += "?" + urlencode(qparams)

            resp = await client.get(url, headers=headers)
            resp.raise_for_status()
            return [types.TextContent(type="text", text=resp.text)]

        # 8) availability
        elif name == "availability":
            qparams = {}

            if "calendar_ids" in arguments:
                qparams["calendar_ids"] = arguments["calendar_ids"]

            # start/end required
            qparams["start"] = arguments["start"]
            qparams["end"]   = arguments["end"]

            # working_hours_only = "true" or "false" (default "true")
            working_hours_only = arguments.get("working_hours_only", "true")
            if working_hours_only not in ["true", "false"]:
                working_hours_only = "true"
            qparams["working_hours_only"] = working_hours_only

            # min_duration
            if "min_duration" in arguments and arguments["min_duration"]:
                qparams["min_duration"] = arguments["min_duration"]

            if "intersect" in arguments:
                # must be JSON-encoded
                intersect_json = json.dumps(arguments["intersect"])
                qparams["intersect"] = intersect_json

            url = f"{EXOSELF_BASE_URL}/availability"
            if qparams:
                url += "?" + urlencode(qparams)

            resp = await client.get(url, headers=headers)
            resp.raise_for_status()
            return [types.TextContent(type="text", text=resp.text)]

        else:
            raise ValueError(f"Unknown tool: {name}")


##############################################################
# MAIN
##############################################################

async def main():
    """
    1. Pre-fetch /user to load global user info (time zone, about, etc.).
    2. Start the MCP server.
    """
    await fetch_user_info_on_startup()

    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="ExoSelf Calendar MCP",
                server_version="1.3.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )

if __name__ == "__main__":
    asyncio.run(main())
