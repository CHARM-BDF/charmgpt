tail -n 20 -f ~/Library/Logs/Claude/mcp*.log
